<!Doctype html>
<html lang="en">

    <head>
        
           <!-- header CDN links -->
      <?php include 'includes/header.php'?>
      <!-- header CDN links -->
      
      
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="https://gliss.in/assets/img/logo/logo.png">

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

        <!-- css file -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- font awesome icon link -->
        <script src="https://kit.fontawesome.com/ed6360e682.js" crossorigin="anonymous"></script>

        <!-- google font -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link
            href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
            rel="stylesheet">

        <!-- font awesome icon link -->
        <script src="https://kit.fontawesome.com/327cf3a5b0.js" crossorigin="anonymous"></script>

        <!-- Owl Carousel -->
        <!-- ----------------------------------------------------------------------------------- -->
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" />
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
        <!-- ----------------------------------------------------------------------------------- -->

        <title> Beauty Makeup: The Permanent SERVICE MANICURE & PEDICURE Solution</title>

        <meta name="description"
            content="Our laser hair removal services can help you achieve the smooth skin you've always wanted! We offer treatments for full body, full face, bikini, chest, full legs, and underarms." />


    </head>

    <body>
        
   <!-- navigation bar -->
      <?php include 'includes/navbar.php'?>
      <!-- navigation bar -->
      
        <!-- modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content modal_bg">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Get In Touch With Us</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="company_form">
                            <div class="mb-3">
                                <label for="name" class="col-form-label">Name</label>
                                <input type="name" class="form-control" id="name" name="name"
                                    placeholder="Enter your Name" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="col-form-label">Phone</label>
                                <input type="tel" class="form-control" id="phone" name="phone"
                                    placeholder="Enter your phone" required>
                            </div>
                            <label for="select" class="col-form-label">Select Treatment</label>
                            <select class="form-select" aria-label="Default select example" name="treatment"
                                id="treatment" required>
                                <option selected>Options</option>
                                <option value="Body Waxing" data-id='Body Waxing'>Body Waxing</option>
                                <option value="Bikini Wax" data-id='Bikini Wax'>Bikini Wax</option>
                                <option value="Body Bleach" data-id='Body Bleach'>Body Bleach</option>
                                <option value="Body Polish" data-id='Body Polish'>Body Polish</option>
                                <option value="Body Scrub" data-id='Body Scrub'>Body Scrub</option>
                                <option value="Facial" data-id='Facial'>Facial</option>
                                <option value="Face Clean-up" data-id='Face Clean-up'>Face Clean-up</option>
                                <option value="Face Dtan Bleach" data-id='Face Dtan Bleach'>Face Dtan Bleach</option>
                                <option value="Manicure Pedicure" data-id='Manicure Pedicure'>Manicure Pedicure</option>
                                <option value="Hair cut + Spa" data-id='Hair cut + Spa'>Hair cut + Spa</option>
                                <option value="D-Tan/Bleach" data-id='D-Tan/Bleach'>D-Tan/Bleach</option>
                                <option value="Rica Waxing" data-id='Rica Waxing'>Rica Waxing</option>
                            </select>
                            <br>
                            <button type="submit" class="btn btn-dark appoint">Send message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
       
      
       

        <!-- hero section start -->
        <section class="hero mhero ">
            <div class="container h-100">
                <div class="row h-100 position-relative">
                    <div class="col-md-8 my-md-auto">
                        <div class="header_content">
                            <h4 class="header_heading">Clean Groomed</h4>
                            <p class="header_heading11">AND FABULOUS</p>
                            <!-- <p><span>Advance</span><strong> LASER</strong></p> -->
                            <div class="fifty_off">
                                <div class="get_ver">
                                    <!-- <span>GET</span> -->
                                    <span>UP</span>
                                    <span> TO</span>
                                </div>
                                <span class="persent">50 <sup>%</sup></span>
                                <span class="off">OFF</span>
                            </div>
                            <!-- <h4 class="laser">ON LASER TREATMENTS</h4> -->
                        </div>
                    </div>

                    <div class="col-md-2 h-100">
                        <button class="btn hero_btn" data-bs-toggle="modal" data-bs-target="#exampleModal">Book
                            Now</button>
                    </div>


                    <!-- <div class="col-md-2 my-auto">
                        <button class="btn hero_btn" data-bs-toggle="modal" data-bs-target="#exampleModal">Book
                            Now</button>
                    </div> -->
                </div>
            </div>
        </section>
        <!-- hero section end -->



        <section class="py-4 pb-2 mt-5"  id="service11">
            <div class="container">
              <div class="row">
                <div class="col-md-12 m-auto text-start">
                    <h1 class="mb-3 text-sm-center text-center  heading1">Best Unisex Salon in Noida
      </h1>
                  <p class="mt-lg-4" style="text-align: justify bg-dark;">
                
                
                
                
    Laser hair removal is indeed a popular method of hair removal that has gained significant popularity in recent years. It offers a more permanent solution compared to temporary methods like shaving, waxing, or using depilatory creams. Let's explore laser hair removal in more detail.
    
    How it works:
    Laser hair removal works by targeting the pigment (melanin) in the hair follicles with concentrated beams of light. The pigment absorbs the light energy, which converts to heat, damaging the hair follicle and inhibiting future hair growth. The laser selectively targets the hair follicles while minimizing damage to the surrounding skin.
    
    Effectiveness:
    Laser hair removal is highly effective in reducing hair growth. However, it is important to note that it is not entirely permanent. Multiple sessions are typically required to achieve the desired results. The number of sessions can vary depending on factors such as the individual's hair type, color, thickness, and the area being treated.Gliss is the <strong>best salon in Noida</strong>, Sector 18 to enhance your beauty and looks. Try our services once, we will not let you down.
                
    
    .</p>
                </div>
              </div>
            </div>
          </section>

        <!-- after hero section start -->
        <section id="service">
            <div class="container py-4">
                <div class="col-md-7 m-auto">
                    <h1 class="heading">Our Beauty Packages </h1>
                </div>

                <div class="col-md-12 m-auto mt-lg-5">
                    <div class="row text-center px-3">

                        <div class="col-md-4 cards mb-4 mb-lg-4">
                            <div class="service_card">
                                <div class="card_img">
                                    <img src="assets/img/pack1.png" alt="" class="img-fluid">
                                </div>
                                <div class="card_content">
                                    <span class="card_headingg" style="font-size: 1.5rem;">Hair cut + Spa </span>
                                    <span class="price">Rs 999  &nbsp; <del>Rs 1,999</del></span>
                                    <button class="btn book_now" data-name="Hair cut + Spa " data-bs-toggle="modal"
                                        data-bs-target="#pack1">Book Now</button>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 cards mb-4 mb-lg-4">
                            <div class="service_card">
                                <div class="card_img">
                                    <img src="assets/img/pack2.png" alt="" class="img-fluid">
                                </div>
                                <div class="card_content">
                                    <span class="card_headingg">D-Tan/Bleach + Normal Waxing(FL,HL) + Upper Lips/Thrading</span>
                                    <span class="price">Rs 1,499  &nbsp; <del>Rs 2,999</del></span>
                                    <button class="btn book_now" data-name="D-Tan/Bleach + Normal Waxing(FL,HL) + Upper Lips/Thrading" data-bs-toggle="modal"
                                        data-bs-target="#pack2">Book Now</button>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 cards mb-4 mb-lg-4">
                            <div class="service_card">
                                <div class="card_img">
                                    <img src="assets/img/pack3.png" alt="" class="img-fluid">
                                </div>
                                <div class="card_content">
                                    <span class="card_headingg">Rica Waxing(FH + HL + UA) + Pedicure + Massage (H/B) + Clean-up + Thrading</span>
                                    <span class="price">Rs 1,499  &nbsp; <del>Rs 2,999</del></span>
                                    <button class="btn book_now" data-name="Rica Waxing(FH + HL + UA) + Pedicure + Massage (H/B) + Clean-up + Thrading" data-bs-toggle="modal"
                                        data-bs-target="#pack3">Book Now</button>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </section>
        <!-- after hero section end -->

        <!-- after hero section start -->
        <section id="service">
            <div class="container py-4">
                <div class="col-md-7 m-auto">
                    <h1 class="heading">SERVICE MANICURE & PEDICURE</h1>
                </div>

                <div class="col-md-12 m-auto mt-lg-5">
                    <div class="row text-center px-3">

                        <div class="col-md-4 cards mb-4 mb-lg-4">
                            <div class="service_card">
                                <div class="card_img">
                                    <img src="assets/img/Body_Wax.png" alt="" class="img-fluid">
                                </div>
                                <div class="card_content">
                                    <span class="card_heading">Body Waxing</span>
                                    <span class="price">Rs 2,999  &nbsp; <del>Rs 5,999</del></span>
                                    <button class="btn book_now" data-name="Body Waxing" data-bs-toggle="modal"
                                        data-bs-target="#exampleModal1">Book Now</button>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 cards mb-4 mb-lg-4">
                            <div class="service_card">
                                <div class="card_img">
                                    <img src="assets/img/Bikini_Wax.png" alt="" class="img-fluid">
                                </div>
                                <div class="card_content">
                                    <span class="card_heading">Bikini Wax</span>
                                    <span class="price">Rs 1,499  &nbsp; <del>Rs 2,999</del></span>
                                    <button class="btn book_now" data-name="Bikini Wax" data-bs-toggle="modal"
                                        data-bs-target="#exampleModal2">Book Now</button>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 cards mb-4 mb-lg-4">
                            <div class="service_card">
                                <div class="card_img">
                                    <img src="assets/img/Body_Bleach.png" alt="" class="img-fluid">
                                </div>
                                <div class="card_content">
                                    <span class="card_heading">Body Bleach</span>
                                    <span class="price">Rs 2,999  &nbsp; <del>Rs 5,999</del></span>
                                    <button class="btn book_now" data-name="Body Bleach" data-bs-toggle="modal"
                                        data-bs-target="#exampleModal3">Book Now</button>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 cards mb-4 mb-lg-4">
                            <div class="service_card">
                                <div class="card_img">
                                    <img src="assets/img/Body_Polish.png" alt="" class="img-fluid">
                                </div>
                                <div class="card_content">
                                    <span class="card_heading">Body Polish</span>
                                    <span class="price">Rs 2,499  &nbsp; <del>Rs 4,999</del></span>
                                    <button class="btn book_now" data-name="Body Polish" data-bs-toggle="modal"
                                        data-bs-target="#exampleModal4">Book Now</button>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 cards mb-4 mb-lg-4">
                            <div class="service_card">
                                <div class="card_img">
                                    <img src="assets/img/Body_Scrub.png" alt="" class="img-fluid">
                                </div>
                                <div class="card_content">
                                    <span class="card_heading">Body Scrub</span>
                                    <span class="price">Rs 1,999  &nbsp; <del>Rs 3,999</del></span>
                                    <button class="btn book_now" data-name="Body Scrub" data-bs-toggle="modal"
                                        data-bs-target="#exampleModal5">Book Now</button>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 cards mb-4 mb-lg-4">
                            <div class="service_card">
                                <div class="card_img">
                                    <img src="assets/img/Facial.png" alt="" class="img-fluid">
                                </div>
                                <div class="card_content">
                                    <span class="card_heading">Facial</span>
                                    <span class="price">Rs 1,499  &nbsp; <del>Rs 2,999</del></span>
                                    <button class="btn book_now" data-name="Facial" data-bs-toggle="modal"
                                        data-bs-target="#exampleModal6">Book Now</button>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 cards mb-4 mb-lg-4">
                            <div class="service_card">
                                <div class="card_img">
                                    <img src="assets/img/Face_Cleanup.png" alt="" class="img-fluid">
                                </div>
                                <div class="card_content">
                                    <span class="card_heading">Face Clean-up</span>
                                    <span class="price">Rs 1,499  &nbsp; <del>Rs 2,999</del></span>
                                    <button class="btn book_now" data-name="Face Clean-up" data-bs-toggle="modal"
                                        data-bs-target="#exampleModal7">Book Now</button>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 cards mb-4 mb-lg-4">
                            <div class="service_card">
                                <div class="card_img">
                                    <img src="assets/img/Face_Dtan_Bleach.png" alt="" class="img-fluid">
                                </div>
                                <div class="card_content">
                                    <span class="card_heading">Face Dtan Bleach</span>
                                    <span class="price">Rs 499  &nbsp; <del>Rs 999</del></span>
                                    <button class="btn book_now" data-name="Face Dtan Bleach" data-bs-toggle="modal"
                                        data-bs-target="#exampleModal8">Book Now</button>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 cards mb-4 mb-lg-4">
                            <div class="service_card">
                                <div class="card_img">
                                    <img src="assets/img/Manicure_Pedicure.png" alt="" class="img-fluid">
                                </div>
                                <div class="card_content">
                                    <span class="card_heading">Manicure Pedicure</span>
                                    <span class="price">Rs 499  &nbsp; <del>Rs 999</del></span>
                                    <button class="btn book_now" data-name="Manicure Pedicure" data-bs-toggle="modal"
                                        data-bs-target="#exampleModal9">Book Now</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- after hero section end -->


        <!-- why choose us section start -->
        <section class="whychooseus mwhychooseus">
            <div class="container-fluid h-100">
                <div class="row h-100">
                    <div class="col-md-5 mt-4 ms-auto">
                        <div class="wcu">
                            <h3 class="wcu_heading">Why Choose Us</h3>
                            <p class="wcu_pra mb-3">Our clinic has a team of certified and experienced technicians who
                                are
                                dedicated to providing personalized attention and care to each client. We understand
                                that every client's needs are different, which is why we take the time to understand
                                your specific requirements and recommend the best treatment plan for you.</p>
                            <div class="pointss">
                                <div class="point">
                                    <img src="assets/img/1.png" alt="" class="img-fluid">
                                    <div><strong>100% NATURAL</strong><br>PRODUCTS</div>
                                </div>
                                <div class="point">
                                    <img src="assets/img/2.png" alt="" class="img-fluid">
                                    <div><strong>PROFESSIONAL</strong><br>STAFFS</div>
                                </div>
                                <div class="point">
                                    <img src="assets/img/3.png" alt="" class="img-fluid">
                                    <div><strong>SPECIAL OFFERS</strong><br>FOR YOU</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- why choose us section end -->

        <!-- about section start -->
        <section class="about py-5 px-3">
            <div class="container">
                <div class="row ">
                    <div class="col-md-5 ms-auto">
                        <div class="about-us">
                            <p>
                            <h3>About Gliss</h3>
                            If you're looking for full-body hair removal, our clinic offers a comprehensive service
                            that
                            covers all parts of the body, from the arms and legs to the chest and back. We are a
                            full-service laser hair removal, we use the latest technology and equipment to ensure
                            safe,
                            effective, and pain-free treatment for our clients. Laser hair removal has become an
                            increasingly popular method of hair removal, thanks to its effectiveness and
                            long-lasting
                            results. If you're looking for the best laser hair removal clinic in Noida, look no
                            further than
                            our clinic. We offer a range of laser hair removal services, including full body hair
                            removal,
                            underarms hair removal, Facial hair removal, and bikini hair removal.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- about section end -->

        <section id="product" class="py-4">
            <div class="container mb-5">
                <div class="row">
                    <div class="col-md-10 m-auto text-center ">
                        <h4 class="content_heading">The Best Products and Brands Used by Our Expert Stylists</h4>
                    </div>
                </div>
            </div>
            <img src="assets/img/Products.jpg" alt="" class="img-fluid d-none d-lg-block d-md-block d-sm-none">
            <img src="assets/img/Products_Mobile.jpg" alt="" class="img-fluid d-block d-lg-none d-md-none d-sm-block">
        </section>

        <!-- testimonial section start -->
        <section class="testimonial py-5" id="review">
            <div class="container">

                <div class="client-review">
                    <h4 class="content_heading text-center ">What Patient's Say Us</h4>
                    <p class="client-review_para">We are happy to share our patient's tesitmonial and reviews with you.
                    </p>
                    <div class="client-slide">
                        <div class="owl-carousel owl-theme owl-loaded owl-drag" id="carousel1">
                            <div class="owl-stage-outer">
                                <div class="owl-stage"
                                    style="transform: translate3d(-1125px, 0px, 0px); transition: all 0.25s ease 0s; width: 4504px;">
                                    <div class="owl-item " style="width: 365.333px; margin-right: 10px;">
                                        <div class="item">
                                            <div class="client-image">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <h5 class="card-title">Meenu jain</h5>
                                                        <h6 class="card-subtitle mb-2 "><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i></h6>
                                                        <p class="card-text">Amazing results after full leg laser hair
                                                            removal! Quick and virtually painless. Highly recommend for
                                                            a permanent hair removal solution.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="owl-item " style="width: 365.333px; margin-right: 10px;">
                                        <div class="item">
                                            <div class="client-image">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <h5 class="card-title">Sheetal sharma</h5>
                                                        <h6 class="card-subtitle mb-2 "><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i></h6>
                                                        <p class="card-text">Only in about 3 treatments on my underarms,
                                                            the hair is totally gone. I highly recommend this treatment
                                                            to anyone looking for a more permanent solution to underarm
                                                            hair removal.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="owl-item " style="width: 365.333px; margin-right: 10px;">
                                        <div class="item">
                                            <div class="client-image">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <h5 class="card-title">Karishma Rajput</h5>
                                                        <h6 class="card-subtitle mb-2 "><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i></h6>
                                                        <p class="card-text">The treatment was quick and virtually
                                                            painless, and I noticed a significant reduction in hair
                                                            growth after just a few sessions.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="owl-item " style="width: 365.333px; margin-right: 10px;">
                                        <div class="item">
                                            <div class="client-image">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <h5 class="card-title">Somya sharma</h5>
                                                        <h6 class="card-subtitle mb-2 "><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i></h6>
                                                        <p class="card-text">Laser hair removal for my upper lip and
                                                            chin has been life-changing. The treatment was painless,
                                                            quick and easy.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="owl-item " style="width: 365.333px; margin-right: 10px;">
                                        <div class="item">
                                            <div class="client-image">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <h5 class="card-title">Reetu panwar</h5>
                                                        <h6 class="card-subtitle mb-2 "><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i></h6>
                                                        <p class="card-text">I'm so happy with the results of my full
                                                            body laser hair removal treatment, and the treatment itself
                                                            was painless.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="owl-item " style="width: 365.333px; margin-right: 10px;">
                                        <div class="item">
                                            <div class="client-image">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <h5 class="card-title">Namrata kanojia</h5>
                                                        <h6 class="card-subtitle mb-2 "><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i></h6>
                                                        <p class="card-text">Quick, easy, and painless - I highly
                                                            recommend laser hair removal .The staff were friendly and
                                                            professional throughout the process. </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- testimonial section end -->


        <!-- footer section start -->
        <section class="footer py-5">
            <div class="container">
                <div class="row">
                    <div class="col-md-10 m-auto footer_text">
                        <h4 class="footer_heading">
                            Contact Us
                        </h4>
                        <p class="addr">J-13, 1st Floor, J Block, Pocket G, Sector 18, Noida, Uttar Pradesh 201301</p>
                        <p class="numbers"> 01204134403 / +91 96670 22241</p>
                    </div>

                    <div class="col-md-6 m-auto">
                        <div>
                            <div class="modal-content modal_bg">
                                <h4 class="text-center m-3"> BOOK AN APPOINTMENT NOW</h4>
                                <div class="modal-body">
                                    <form class="company_form">
                                        <div class="mb-3">
                                            <label for="name" class="col-form-label">Name</label>
                                            <input type="name" class="form-control" id="name" name="name"
                                                placeholder="Enter your Name" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="phone" class="col-form-label">Phone</label>
                                            <input type="tel" class="form-control" id="phone" name="phone"
                                                placeholder="Enter your phone" required>
                                        </div>
                                        <label for="select" class="col-form-label">Select Treatment</label>
                                        <select class="form-select" aria-label="Default select example" name="treatment"
                                            id="treatment" required>
                                            <option selected>Options</option>
                                            <option value="Body Waxing" data-id='Body Waxing'>Body Waxing</option>
                                            <option value="Bikini Wax" data-id='Bikini Wax'>Bikini Wax</option>
                                            <option value="Body Bleach" data-id='Body Bleach'>Body Bleach</option>
                                            <option value="Body Polish" data-id='Body Polish'>Body Polish</option>
                                            <option value="Body Scrub" data-id='Body Scrub'>Body Scrub</option>
                                            <option value="Facial" data-id='Facial'>Facial</option>
                                            <option value="Face Clean-up" data-id='Face Clean-up'>Face Clean-up</option>
                                            <option value="Face Dtan Bleach" data-id='Face Dtan Bleach'>Face Dtan Bleach
                                            </option>
                                            <option value="Manicure Pedicure" data-id='Manicure Pedicure'>Manicure
                                                Pedicure</option>
                                        </select>
                                        <br>
                                        <button type="submit" class="btn btn-dark appoint">Send message</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 m-auto text-center">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14016.140039861!2d77.324276!3d28.5687114!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce513e54b6813%3A0xb6f1d0c4da258a32!2sGliss%20Unisex%20Salon%20%7C%20Beauty%20%26%20Haircare!5e0!3m2!1sen!2sin!4v1681882840077!5m2!1sen!2sin"
                            width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </div>
            </div>
        </section>
        <!-- footer section end -->

           <!--citys icons footer section end-->






        <a href="tel:+919667022241" class="float-button-call"><i class="fa-solid fa-phone"></i></a>
        <a href="https://wa.me/919667022241" class="float-button-whatsapp"><i class="fa-brands fa-whatsapp"></i></a>
        
          <!-- footer -->
      <div style="height: 50px;"></div>
      <?php include 'includes/footer.php'?>
      <!-- footer -->
      <!-- footer CDN links -->
      <?php include 'includes/footer_script.php'?>
      <script src="libraries/sweetalert/sweetalert.min.js"></script>
      <script type="text/javascript" id="salonistScript" src="https://gliss.salonist.io/js/booking-button.js"></script>
      <!-- footer CDN links -->


        <!--pop up for cards -->

        <div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content modal_bg">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Get In Touch With Us</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="company_form">
                            <div class="mb-3">
                                <label for="name" class="col-form-label">Name</label>
                                <input type="name" class="form-control" id="name" name="name"
                                    placeholder="Enter your Name" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="col-form-label">Phone</label>
                                <input type="tel" class="form-control" id="phone" name="phone"
                                    placeholder="Enter your phone" required>
                            </div>
                            <label for="select" class="col-form-label">Select Treatment</label>
                            <select class="form-select" aria-label="Default select example" name="treatment"
                                id="treatment" required>
                                <option>Options</option>
                                <option value="Body Waxing" data-id='Body Waxing' selected>Body Waxing</option>
                                <option value="Bikini Wax" data-id='Bikini Wax'>Bikini Wax</option>
                                <option value="Body Bleach" data-id='Body Bleach'>Body Bleach</option>
                                <option value="Body Polish" data-id='Body Polish'>Body Polish</option>
                                <option value="Body Scrub" data-id='Body Scrub'>Body Scrub</option>
                                <option value="Facial" data-id='Facial'>Facial</option>
                                <option value="Face Clean-up" data-id='Face Clean-up'>Face Clean-up</option>
                                <option value="Face Dtan Bleach" data-id='Face Dtan Bleach'>Face Dtan Bleach</option>
                                <option value="Manicure Pedicure" data-id='Manicure Pedicure'>Manicure Pedicure</option>
                                <option value="Hair cut + Spa" data-id='Hair cut + Spa'>Hair cut + Spa</option>
                                <option value="D-Tan/Bleach" data-id='D-Tan/Bleach'>D-Tan/Bleach</option>
                                <option value="Rica Waxing" data-id='Rica Waxing'>Rica Waxing</option>
                            </select>
                            <br>
                            <button type="submit" class="btn btn-dark appoint">Send message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content modal_bg">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Get In Touch With Us</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="company_form">
                            <div class="mb-3">
                                <label for="name" class="col-form-label">Name</label>
                                <input type="name" class="form-control" id="name" name="name"
                                    placeholder="Enter your Name" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="col-form-label">Phone</label>
                                <input type="tel" class="form-control" id="phone" name="phone"
                                    placeholder="Enter your phone" required>
                            </div>
                            <label for="select" class="col-form-label">Select Treatment</label>
                            <select class="form-select" aria-label="Default select example" name="treatment"
                                id="treatment" required>
                                <option>Options</option>
                                <option value="Body Waxing" data-id='Body Waxing'>Body Waxing</option>
                                <option value="Bikini Wax" data-id='Bikini Wax' selected>Bikini Wax</option>
                                <option value="Body Bleach" data-id='Body Bleach'>Body Bleach</option>
                                <option value="Body Polish" data-id='Body Polish'>Body Polish</option>
                                <option value="Body Scrub" data-id='Body Scrub'>Body Scrub</option>
                                <option value="Facial" data-id='Facial'>Facial</option>
                                <option value="Face Clean-up" data-id='Face Clean-up'>Face Clean-up</option>
                                <option value="Face Dtan Bleach" data-id='Face Dtan Bleach'>Face Dtan Bleach</option>
                                <option value="Manicure Pedicure" data-id='Manicure Pedicure'>Manicure Pedicure</option>
                                <option value="Hair cut + Spa" data-id='Hair cut + Spa'>Hair cut + Spa</option>
                                <option value="D-Tan/Bleach" data-id='D-Tan/Bleach'>D-Tan/Bleach</option>
                                <option value="Rica Waxing" data-id='Rica Waxing'>Rica Waxing</option>
                            </select>
                            <br>
                            <button type="submit" class="btn btn-dark appoint">Send message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade" id="exampleModal3" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content modal_bg">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Get In Touch With Us</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="company_form">
                            <div class="mb-3">
                                <label for="name" class="col-form-label">Name</label>
                                <input type="name" class="form-control" id="name" name="name"
                                    placeholder="Enter your Name" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="col-form-label">Phone</label>
                                <input type="tel" class="form-control" id="phone" name="phone"
                                    placeholder="Enter your phone" required>
                            </div>
                            <label for="select" class="col-form-label">Select Treatment</label>
                            <select class="form-select" aria-label="Default select example" name="treatment"
                                id="treatment" required>
                                <option>Options</option>
                                <option value="Body Waxing" data-id='Body Waxing'>Body Waxing</option>
                                <option value="Bikini Wax" data-id='Bikini Wax'>Bikini Wax</option>
                                <option value="Body Bleach" data-id='Body Bleach' selected>Body Bleach</option>
                                <option value="Body Polish" data-id='Body Polish'>Body Polish</option>
                                <option value="Body Scrub" data-id='Body Scrub'>Body Scrub</option>
                                <option value="Facial" data-id='Facial'>Facial</option>
                                <option value="Face Clean-up" data-id='Face Clean-up'>Face Clean-up</option>
                                <option value="Face Dtan Bleach" data-id='Face Dtan Bleach'>Face Dtan Bleach</option>
                                <option value="Manicure Pedicure" data-id='Manicure Pedicure'>Manicure Pedicure</option>
                                <option value="Hair cut + Spa" data-id='Hair cut + Spa'>Hair cut + Spa</option>
                                <option value="D-Tan/Bleach" data-id='D-Tan/Bleach'>D-Tan/Bleach</option>
                                <option value="Rica Waxing" data-id='Rica Waxing'>Rica Waxing</option>
                            </select>
                            <br>
                            <button type="submit" class="btn btn-dark appoint">Send message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade" id="exampleModal4" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content modal_bg">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Get In Touch With Us</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="company_form">
                            <div class="mb-3">
                                <label for="name" class="col-form-label">Name</label>
                                <input type="name" class="form-control" id="name" name="name"
                                    placeholder="Enter your Name" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="col-form-label">Phone</label>
                                <input type="tel" class="form-control" id="phone" name="phone"
                                    placeholder="Enter your phone" required>
                            </div>
                            <label for="select" class="col-form-label">Select Treatment</label>
                            <select class="form-select" aria-label="Default select example" name="treatment"
                                id="treatment" required>
                                <option>Options</option>
                                <option value="Body Waxing" data-id='Body Waxing'>Body Waxing</option>
                                <option value="Bikini Wax" data-id='Bikini Wax'>Bikini Wax</option>
                                <option value="Body Bleach" data-id='Body Bleach'>Body Bleach</option>
                                <option value="Body Polish" data-id='Body Polish' selected>Body Polish</option>
                                <option value="Body Scrub" data-id='Body Scrub'>Body Scrub</option>
                                <option value="Facial" data-id='Facial'>Facial</option>
                                <option value="Face Clean-up" data-id='Face Clean-up'>Face Clean-up</option>
                                <option value="Face Dtan Bleach" data-id='Face Dtan Bleach'>Face Dtan Bleach</option>
                                <option value="Manicure Pedicure" data-id='Manicure Pedicure'>Manicure Pedicure</option>
                                <option value="Hair cut + Spa" data-id='Hair cut + Spa'>Hair cut + Spa</option>
                                <option value="D-Tan/Bleach" data-id='D-Tan/Bleach'>D-Tan/Bleach</option>
                                <option value="Rica Waxing" data-id='Rica Waxing'>Rica Waxing</option>
                            </select>
                            <br>
                            <button type="submit" class="btn btn-dark appoint">Send message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="exampleModal5" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content modal_bg">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Get In Touch With Us</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="company_form">
                            <div class="mb-3">
                                <label for="name" class="col-form-label">Name</label>
                                <input type="name" class="form-control" id="name" name="name"
                                    placeholder="Enter your Name" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="col-form-label">Phone</label>
                                <input type="tel" class="form-control" id="phone" name="phone"
                                    placeholder="Enter your phone" required>
                            </div>
                            <label for="select" class="col-form-label">Select Treatment</label>
                            <select class="form-select" aria-label="Default select example" name="treatment"
                                id="treatment" required>
                                <option>Options</option>
                                <option value="Body Waxing" data-id='Body Waxing'>Body Waxing</option>
                                <option value="Bikini Wax" data-id='Bikini Wax'>Bikini Wax</option>
                                <option value="Body Bleach" data-id='Body Bleach'>Body Bleach</option>
                                <option value="Body Polish" data-id='Body Polish' selected>Body Polish</option>
                                <option value="Body Scrub" data-id='Body Scrub' selected>Body Scrub</option>
                                <option value="Facial" data-id='Facial'>Facial</option>
                                <option value="Face Clean-up" data-id='Face Clean-up'>Face Clean-up</option>
                                <option value="Face Dtan Bleach" data-id='Face Dtan Bleach'>Face Dtan Bleach</option>
                                <option value="Manicure Pedicure" data-id='Manicure Pedicure'>Manicure Pedicure</option>
                                <option value="Hair cut + Spa" data-id='Hair cut + Spa'>Hair cut + Spa</option>
                                <option value="D-Tan/Bleach" data-id='D-Tan/Bleach'>D-Tan/Bleach</option>
                                <option value="Rica Waxing" data-id='Rica Waxing'>Rica Waxing</option>
                            </select>
                            <br>
                            <button type="submit" class="btn btn-dark appoint">Send message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="exampleModal6" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content modal_bg">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Get In Touch With Us</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="company_form">
                            <div class="mb-3">
                                <label for="name" class="col-form-label">Name</label>
                                <input type="name" class="form-control" id="name" name="name"
                                    placeholder="Enter your Name" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="col-form-label">Phone</label>
                                <input type="tel" class="form-control" id="phone" name="phone"
                                    placeholder="Enter your phone" required>
                            </div>
                            <label for="select" class="col-form-label">Select Treatment</label>
                            <select class="form-select" aria-label="Default select example" name="treatment"
                                id="treatment" required>
                                <option>Options</option>
                                <option value="Body Waxing" data-id='Body Waxing'>Body Waxing</option>
                                <option value="Bikini Wax" data-id='Bikini Wax'>Bikini Wax</option>
                                <option value="Body Bleach" data-id='Body Bleach'>Body Bleach</option>
                                <option value="Body Polish" data-id='Body Polish' selected>Body Polish</option>
                                <option value="Body Scrub" data-id='Body Scrub'>Body Scrub</option>
                                <option value="Facial" data-id='Facial' selected>Facial</option>
                                <option value="Face Clean-up" data-id='Face Clean-up'>Face Clean-up</option>
                                <option value="Face Dtan Bleach" data-id='Face Dtan Bleach'>Face Dtan Bleach</option>
                                <option value="Manicure Pedicure" data-id='Manicure Pedicure'>Manicure Pedicure</option>
                                <option value="Hair cut + Spa" data-id='Hair cut + Spa'>Hair cut + Spa</option>
                                <option value="D-Tan/Bleach" data-id='D-Tan/Bleach'>D-Tan/Bleach</option>
                                <option value="Rica Waxing" data-id='Rica Waxing'>Rica Waxing</option>
                            </select>
                            <br>
                            <button type="submit" class="btn btn-dark appoint">Send message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="exampleModal7" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content modal_bg">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Get In Touch With Us</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="company_form">
                            <div class="mb-3">
                                <label for="name" class="col-form-label">Name</label>
                                <input type="name" class="form-control" id="name" name="name"
                                    placeholder="Enter your Name" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="col-form-label">Phone</label>
                                <input type="tel" class="form-control" id="phone" name="phone"
                                    placeholder="Enter your phone" required>
                            </div>
                            <label for="select" class="col-form-label">Select Treatment</label>
                            <select class="form-select" aria-label="Default select example" name="treatment"
                                id="treatment" required>
                                <option>Options</option>
                                <option value="Body Waxing" data-id='Body Waxing'>Body Waxing</option>
                                <option value="Bikini Wax" data-id='Bikini Wax'>Bikini Wax</option>
                                <option value="Body Bleach" data-id='Body Bleach'>Body Bleach</option>
                                <option value="Body Polish" data-id='Body Polish' selected>Body Polish</option>
                                <option value="Body Scrub" data-id='Body Scrub'>Body Scrub</option>
                                <option value="Facial" data-id='Facial'>Facial</option>
                                <option value="Face Clean-up" data-id='Face Clean-up' selected>Face Clean-up</option>
                                <option value="Face Dtan Bleach" data-id='Face Dtan Bleach'>Face Dtan Bleach</option>
                                <option value="Manicure Pedicure" data-id='Manicure Pedicure'>Manicure Pedicure</option>
                                <option value="Hair cut + Spa" data-id='Hair cut + Spa'>Hair cut + Spa</option>
                                <option value="D-Tan/Bleach" data-id='D-Tan/Bleach'>D-Tan/Bleach</option>
                                <option value="Rica Waxing" data-id='Rica Waxing'>Rica Waxing</option>
                            </select>
                            <br>
                            <button type="submit" class="btn btn-dark appoint">Send message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="exampleModal8" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content modal_bg">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Get In Touch With Us</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="company_form">
                            <div class="mb-3">
                                <label for="name" class="col-form-label">Name</label>
                                <input type="name" class="form-control" id="name" name="name"
                                    placeholder="Enter your Name" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="col-form-label">Phone</label>
                                <input type="tel" class="form-control" id="phone" name="phone"
                                    placeholder="Enter your phone" required>
                            </div>
                            <label for="select" class="col-form-label">Select Treatment</label>
                            <select class="form-select" aria-label="Default select example" name="treatment"
                                id="treatment" required>
                                <option>Options</option>
                                <option value="Body Waxing" data-id='Body Waxing'>Body Waxing</option>
                                <option value="Bikini Wax" data-id='Bikini Wax'>Bikini Wax</option>
                                <option value="Body Bleach" data-id='Body Bleach'>Body Bleach</option>
                                <option value="Body Polish" data-id='Body Polish' selected>Body Polish</option>
                                <option value="Body Scrub" data-id='Body Scrub'>Body Scrub</option>
                                <option value="Facial" data-id='Facial'>Facial</option>
                                <option value="Face Clean-up" data-id='Face Clean-up'>Face Clean-up</option>
                                <option value="Face Dtan Bleach" data-id='Face Dtan Bleach' selected>Face Dtan Bleach
                                </option>
                                <option value="Manicure Pedicure" data-id='Manicure Pedicure'>Manicure Pedicure</option>
                                <option value="Hair cut + Spa" data-id='Hair cut + Spa'>Hair cut + Spa</option>
                                <option value="D-Tan/Bleach" data-id='D-Tan/Bleach'>D-Tan/Bleach</option>
                                <option value="Rica Waxing" data-id='Rica Waxing'>Rica Waxing</option>
                            </select>
                            <br>
                            <button type="submit" class="btn btn-dark appoint">Send message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="exampleModal9" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content modal_bg">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Get In Touch With Us</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="company_form">
                            <div class="mb-3">
                                <label for="name" class="col-form-label">Name</label>
                                <input type="name" class="form-control" id="name" name="name"
                                    placeholder="Enter your Name" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="col-form-label">Phone</label>
                                <input type="tel" class="form-control" id="phone" name="phone"
                                    placeholder="Enter your phone" required>
                            </div>
                            <label for="select" class="col-form-label">Select Treatment</label>
                            <select class="form-select" aria-label="Default select example" name="treatment"
                                id="treatment" required>
                                <option>Options</option>
                                <option value="Body Waxing" data-id='Body Waxing'>Body Waxing</option>
                                <option value="Bikini Wax" data-id='Bikini Wax'>Bikini Wax</option>
                                <option value="Body Bleach" data-id='Body Bleach'>Body Bleach</option>
                                <option value="Body Polish" data-id='Body Polish' selected>Body Polish</option>
                                <option value="Body Scrub" data-id='Body Scrub'>Body Scrub</option>
                                <option value="Facial" data-id='Facial'>Facial</option>
                                <option value="Face Clean-up" data-id='Face Clean-up'>Face Clean-up</option>
                                <option value="Face Dtan Bleach" data-id='Face Dtan Bleach'>Face Dtan Bleach</option>
                                <option value="Manicure Pedicure" data-id='Manicure Pedicure' selected>Manicure Pedicure
                                </option>
                                <option value="Hair cut + Spa" data-id='Hair cut + Spa'>Hair cut + Spa</option>
                                <option value="D-Tan/Bleach" data-id='D-Tan/Bleach'>D-Tan/Bleach</option>
                                <option value="Rica Waxing" data-id='Rica Waxing'>Rica Waxing</option>
                            </select>
                            <br>
                            <button type="submit" class="btn btn-dark appoint">Send message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="pack1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content modal_bg">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Get In Touch With Us</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="company_form">
                            <div class="mb-3">
                                <label for="name" class="col-form-label">Name</label>
                                <input type="name" class="form-control" id="name" name="name"
                                    placeholder="Enter your Name" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="col-form-label">Phone</label>
                                <input type="tel" class="form-control" id="phone" name="phone"
                                    placeholder="Enter your phone" required>
                            </div>
                            <label for="select" class="col-form-label">Select Treatment</label>
                            <select class="form-select" aria-label="Default select example" name="treatment"
                                id="treatment" required>
                                <option>Options</option>
                                <option value="Body Waxing" data-id='Body Waxing'>Body Waxing</option>
                                <option value="Bikini Wax" data-id='Bikini Wax'>Bikini Wax</option>
                                <option value="Body Bleach" data-id='Body Bleach'>Body Bleach</option>
                                <option value="Body Polish" data-id='Body Polish' selected>Body Polish</option>
                                <option value="Body Scrub" data-id='Body Scrub'>Body Scrub</option>
                                <option value="Facial" data-id='Facial'>Facial</option>
                                <option value="Face Clean-up" data-id='Face Clean-up'>Face Clean-up</option>
                                <option value="Face Dtan Bleach" data-id='Face Dtan Bleach'>Face Dtan Bleach</option>
                                <option value="Manicure Pedicure" data-id='Manicure Pedicure'>Manicure Pedicure
                                </option>
                                <option value="Hair cut + Spa" data-id='Hair cut + Spa'selected>Hair cut + Spa</option>
                                <option value="D-Tan/Bleach" data-id='D-Tan/Bleach'>D-Tan/Bleach</option>
                                <option value="Rica Waxing" data-id='Rica Waxing'>Rica Waxing</option>
                            </select>
                            <br>
                            <button type="submit" class="btn btn-dark appoint">Send message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="pack2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content modal_bg">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Get In Touch With Us</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="company_form">
                            <div class="mb-3">
                                <label for="name" class="col-form-label">Name</label>
                                <input type="name" class="form-control" id="name" name="name"
                                    placeholder="Enter your Name" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="col-form-label">Phone</label>
                                <input type="tel" class="form-control" id="phone" name="phone"
                                    placeholder="Enter your phone" required>
                            </div>
                            <label for="select" class="col-form-label">Select Treatment</label>
                            <select class="form-select" aria-label="Default select example" name="treatment"
                                id="treatment" required>
                                <option>Options</option>
                                <option value="Body Waxing" data-id='Body Waxing'>Body Waxing</option>
                                <option value="Bikini Wax" data-id='Bikini Wax'>Bikini Wax</option>
                                <option value="Body Bleach" data-id='Body Bleach'>Body Bleach</option>
                                <option value="Body Polish" data-id='Body Polish' selected>Body Polish</option>
                                <option value="Body Scrub" data-id='Body Scrub'>Body Scrub</option>
                                <option value="Facial" data-id='Facial'>Facial</option>
                                <option value="Face Clean-up" data-id='Face Clean-up'>Face Clean-up</option>
                                <option value="Face Dtan Bleach" data-id='Face Dtan Bleach'>Face Dtan Bleach</option>
                                <option value="Manicure Pedicure" data-id='Manicure Pedicure' selected>Manicure Pedicure
                                </option>
                                <option value="Hair cut + Spa" data-id='Hair cut + Spa'>Hair cut + Spa</option>
                                <option value="D-Tan/Bleach" data-id='D-Tan/Bleach'selected>D-Tan/Bleach</option>
                                <option value="Rica Waxing" data-id='Rica Waxing'>Rica Waxing</option>
                            </select>
                            <br>
                            <button type="submit" class="btn btn-dark appoint">Send message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="pack3" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content modal_bg">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Get In Touch With Us</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="company_form">
                            <div class="mb-3">
                                <label for="name" class="col-form-label">Name</label>
                                <input type="name" class="form-control" id="name" name="name"
                                    placeholder="Enter your Name" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="col-form-label">Phone</label>
                                <input type="tel" class="form-control" id="phone" name="phone"
                                    placeholder="Enter your phone" required>
                            </div>
                            <label for="select" class="col-form-label">Select Treatment</label>
                            <select class="form-select" aria-label="Default select example" name="treatment"
                                id="treatment" required>
                                <option>Options</option>
                                <option value="Body Waxing" data-id='Body Waxing'>Body Waxing</option>
                                <option value="Bikini Wax" data-id='Bikini Wax'>Bikini Wax</option>
                                <option value="Body Bleach" data-id='Body Bleach'>Body Bleach</option>
                                <option value="Body Polish" data-id='Body Polish' selected>Body Polish</option>
                                <option value="Body Scrub" data-id='Body Scrub'>Body Scrub</option>
                                <option value="Facial" data-id='Facial'>Facial</option>
                                <option value="Face Clean-up" data-id='Face Clean-up'>Face Clean-up</option>
                                <option value="Face Dtan Bleach" data-id='Face Dtan Bleach'>Face Dtan Bleach</option>
                                <option value="Manicure Pedicure" data-id='Manicure Pedicure' selected>Manicure Pedicure
                                </option>
                                <option value="Hair cut + Spa" data-id='Hair cut + Spa'>Hair cut + Spa</option>
                                <option value="D-Tan/Bleach" data-id='D-Tan/Bleach'>D-Tan/Bleach</option>
                                <option value="Rica Waxing" data-id='Rica Waxing'selected>Rica Waxing</option>
                            </select>
                            <br>
                            <button type="submit" class="btn btn-dark appoint">Send message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>




        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
            crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/jquery-3.6.3.min.js"></script> <!-- jquery cdn -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
        <script type="text/javascript">
            $('.company_form').submit(function (e) {
                e.preventDefault();
                // alert("Form submission prevented!");
                var formData = new FormData(this);
                $.ajax({
                    url: 'mailprocess.php',
                    type: 'POST',
                    contentType: false,
                    processData: false,
                    data: formData,
                    beforeSend: function () {
                        $('.appoint').attr('disabled', true);
                        $('.appoint').html('Please wait...');
                    },
                    success: function (data) {
                        console.log(data);
                        if (data == 1) {
                            $('.company_form').trigger('reset');
                            $("#exampleModal .close").click()
                            window.location = "thankyou.php";
                        }
                    }
                }).done(function () {
                    $('.appoint').attr('disabled', false);
                })

            })


            $(document).on('click', '.book_now', function () {
                var name = $(this).data('name');
                $('#exampleModalLabel').html(name);
            })
        </script>

        <script>
            $('#carousel1').owlCarousel({
                loop: true,
                margin: 10,
                nav: true,
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 2
                    },
                    1000: {
                        items: 2
                    }
                }
            })
            $('#carousel2').owlCarousel({
                loop: true,
                margin: 10,
                nav: true,
                autoplay: true,
                autoplayTimeout: 3000,
                autoplayHoverPause: true,
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 2
                    },
                    1000: {
                        items: 3
                    }
                }
            })
            $('#carousel3').owlCarousel({
                loop: true,
                margin: 10,
                nav: true,
                autoplay: true,
                autoplayTimeout: 3000,
                autoplayHoverPause: true,
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 1
                    },
                    1000: {
                        items: 1
                    }
                }
            })
        </script>


<script>$("#search-icon").click(function() {
    $(".nav").toggleClass("search");
    $(".nav").toggleClass("no-search");
    $(".search-input").toggleClass("search-active");
  });
  
  $('.menu-toggle').click(function(){
     $(".nav").toggleClass("mobile-nav");
     $(this).toggleClass("is-active");
  });</script>
  




        <!--<script src="assets/js/main.js"></script>-->


    </body>

</html>