<script src="../libraries/bootstrap/js/bootstrap.bundle.js"></script>
<script src="../libraries/jquery/script.js"></script>
<script type="text/javascript" src="../assets/js/app.js"></script>
<script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>