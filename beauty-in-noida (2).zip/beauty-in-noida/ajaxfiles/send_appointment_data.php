<?php  
include '../includes/config.php';
$name          = $_POST['name'];
$contact       = $_POST['contact'];
$email         = $_POST['email'];
$gender        = $_POST['gender'];
$serviceType   = $_POST['serviceType'];
$preferredDate = $_POST['preferredDate'];
$preferredTime = $_POST['preferredTime'];
$unique_id     = md5(uniqid($contact, true));
date_default_timezone_set("Asia/Calcutta"); 
$date = date("j-n-Y");
$time = date("g:i a");

if ($name !== '' && $contact !== '' && $gender !== '' && $serviceType !== '' && $preferredDate !== '' && $preferredTime !== '' && $email !== '') {
     $sql = "INSERT INTO `appointment_data`(`date`, `time`, `name`, `gender`, `contact`, `email`, `service_type`, `preferred_date`, `preferred_time`, `status`,`bill_id`) VALUES ('$date','$time','$name','$gender','$contact','$email','$serviceType','$preferredDate','$preferredTime','1','$unique_id')";
     $result = mysqli_query($conn, $sql);
     if ($result) {
     	echo "1";
     } else {
     	echo "0";
     }
}

// INSERT INTO `appointment_data`(`s_no`, `date`, `time`, `name`, `gender`, `contact`, `email`, `service_type`, `preferred_date`, `preferred_time`, `status`, `scheduling`, `assign_to`) VALUES ('[value-1]','[value-2]','[value-3]','[value-4]','[value-5]','[value-6]','[value-7]','[value-8]','[value-9]','[value-10]','[value-11]','[value-12]','[value-13]')
?>