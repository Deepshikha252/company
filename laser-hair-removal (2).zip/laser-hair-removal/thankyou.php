
<!DOCTYPE html>
<html>
  <head>
      
      <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5G976DW');</script>
<!-- End Google Tag Manager -->


  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Thank you</title>
  <!--Google font-->
    <link href="https://fonts.googleapis.com/css2?family=Audiowide&family=Oswald:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon-32x32.png">
    <style>
      body {
        text-align: center;
        padding: 40px 0;
        background:#f700330d;
      }
        h1 {
          color: #f70033;
          font-family: 'Audiowide', cursive;
          font-weight: 900;
          font-size: 40px;
          margin-bottom: 10px;
        }
        p {
          color: #404F5E;
          font-family: "Nunito Sans", "Helvetica Neue", sans-serif;
          font-size:20px;
          margin: 0;
        }
      i {
        color: #f70033;
        font-size: 100px;
        line-height: 200px;
        margin-left:-15px;
      }
      .card {
        background: white;
        padding: 60px;
        border-radius: 4px;
        box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;
        display: inline-block;
        margin: 0 auto;
        width: 80%;
      }
      .button {
      display: inline-block;
          text-align: center;
          text-decoration: none;
          color: #fff;
          font-weight: normal;
          width: 270px;
          height: 50px;
          line-height: 50px;
          font-size: 16px;
          background: #f70033;
          margin-top: 20px;
          border-radius: 10px;
          font-family: "Nunito Sans", "Helvetica Neue", sans-serif;
      }
      .check_outer {
        border-radius:200px;
         height:200px; 
         width:200px; 
         background: #f700330d; 
         margin:0 auto;
      }
      
      @media screen and (max-width:768px) {
        .card {
            width: 70%;
            height: 500px;
            padding: 35px;
        }
        .button {
            width: 200px;
            height: 40px;
            line-height: 40px;
        }
      }
    </style>
  </head>
    
    <body>
        
        <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5G976DW"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

      <div class="card">
        <div class="check_outer">
          <i class="checkmark">&#x2713;</i>
        </div>
          <h1>Success</h1> 
          <p>We received your query :)<br/> we'll be in touch shortly!</p>
          <a class='button' href='https://gliss.in/laser-hair-removal/'>Back to home</a>
      </div>
    </body>
</html>