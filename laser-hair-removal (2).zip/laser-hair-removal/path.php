<?php include './includes/header.php'; ?> 
 <?php include './includes/header-2.php'; ?> 

 <?php include './includes/navbar.php'; ?> 

<?php include './includes/e-nav.php'; ?>


<?php include('index.html'); ?>


<?php include './includes/footer.php'; ?> 

<?php include './includes/footer_script.php'; ?> 

<?php include './includes/footer_script-2.php'; ?> 