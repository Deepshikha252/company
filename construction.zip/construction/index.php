<!doctype html>
<html lang="en">

<head>
   
  <meta name="robots" content="noindex">
 
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="https://www.senseprojects.in/assets/images/logo/fav_icon_.png" sizes="32x32" />
    <!-- <link rel="icon" href="https://www.senseprojects.in/assets/images/logo/fav_icon_.png" sizes="192x192" /> -->
    <title>construction</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- font awesome -->
    <script src="https://kit.fontawesome.com/327cf3a5b0.js" crossorigin="anonymous"></script>

    <!--owl carousel cdn  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">

</head>

<body>
    <!-- pop up modal start -->
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel" style="color: #003f7e;">Get In Touch With Us</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="footer_form" style="margin: auto;">

                    <form  action="thankyou.php"  method="POST"  class="company_form">
                        <!-- <form id="contact" action="thankyou.php" method="POST" class="company_form"> -->
                        <!-- <form  action="thankyou.php" method="POST"> -->
                         
                         
                            <fieldset>
                                <input placeholder="Your name"name="name" type="text" tabindex="1" required>
                            </fieldset>
                            <fieldset>
                                <input placeholder="Your Email Address"name="email" type="email" tabindex="2" required>
                            </fieldset>
                            <fieldset>
                                <input placeholder="Your Phone Number"name="mobile" type="tel" tabindex="3" required>
                            </fieldset>
                            
                             <label for="select" class="col-form-label">Select Services</label>
                            <select class="form-select" aria-label="Default select example" name="services" id="services"
                                required>
                                <option selected>Options</option>
                                <option value="Residential Construction" data-id='Residential Construction'>Residential Construction</option>
                                <option value="Industrial Construction" data-id='Industrial Construction'>Industrial Construction</option>
                                <option value="Commercial Construction" data-id='Commercial Construction'>Commercial Construction</option>
                                <option value="Hospitality Construction" data-id='Hospitality Construction'>Hospitality Construction</option>
                                <option value="Institutional Construction" data-id='Institutional Construction'>Institutional Construction</option>
                                <option value="Warehouse Construction" data-id='Warehouse Construction'>Warehouse Construction</option>
                                
                            </select>
                            <br>
                            
                            <fieldset>
                                <textarea placeholder="Type your message here...." tabindex="6" required></textarea>
                            </fieldset>
                            
                           
                            <fieldset>
                                <button name="submit" type="submit"  class="appoint"id="contact-submit" data-submit="...Sending">Send
                                    Message</button>
                            </fieldset>
                        </form>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary " data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div> 
    <!-- pop up modal end -->

    <!-- header start -->
    <section id="header" class="py-2">
        <div class="container-header ">
            <div class="logo">
                <img src="https://senseprojects.in/assets/images/logo/Sense_project_logo.png" alt="" class="img-fluid">
            </div>
            <div class="number text-end">
                <a href="tel:+919319412012">+91-9319412012</a>
            </div>
        </div>
    </section>

    <!-- <div class="container">
                <div class="row">
                    <div class="col-6">
                        <div class="logo">
                            <img src="https://senseprojects.in/assets/images/logo/Sense_project_logo.png" alt=""
                                class="img-fluid">
                        </div>
                    </div>
                    <div class="col-6 m-auto">
                        <div class="number text-end">
                            <a href="tel:+919319412012">+91-9319412012</a>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
    <!-- header end -->

    <!-- hero section start -->
    <section id="hero" class=" hero_banner mhero_banner">
        <div class="container ">
            <div class="heroo-text-container">
                <h1 class="heroo_hed mb-3">ALWAYS STRONG <br>FOUNDATION</h1>
                <h2 class="heroo_heading">#NO.1 Leading <span style="">Construction </span>Contractors in India</h2>
                <h2 class="heroo_pra">
                    Your Vision, Our Expertise: Building <br>Extraordinary Structures Together.
                </h2>
            </div>
            <div class="hero-button">
                <button class="btn consultation_Btn" data-toggle="modal" data-target="#exampleModal">Get Free
                    Consultation Now</button>
            </div>
        </div>
    </section>
    <!-- hero section end -->


    <!-- hero section start -->
    <!-- <section id="hero" class="py-4 hero_banner  ">
            <div class="container h-100">
                <div class="row h-100">

                    <div class="col-md-5 mt-4 ms-auto">
                        <div class="heroo">
                            <h1 class="heroo_hed">ALWAYS STRONG <br>FOUNDATION</h1>
                            <h2 class="heroo_heading">#NO.1 Leading Construction Contractors in India</h2>
                            <h2 class="heroo_pra mb-3">
                                Your Vision, Our Expertise: Building <br>Extraordinary Structures Together.  </h2>
                               
                        
                        </div>
                        <div class="consultation_btn_bx">
                            <button class="btn consultation_Btn" data-toggle="modal" data-target="#exampleModal">Get Free Consultation Now</button>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
    <!-- hero section end -->





    <!-- services section start -->
    <section id="services" class="services  servies-uss py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2 class="service_heading">
                        We Provide Below Services
                    </h2>
                </div>

                <div class="service-1 col-md-4 mt-4 mt-lg-5 p-lg-3 text-left mb-4">
                    <!-- <div class="service-1 col-md-4 mt-4 mt-lg-5 p-lg-3 text-center"> -->
                    <div class="services_bx">
                        <div class="service_icon">
                            <img src="assets/img/Icon1.png" alt="" class="img-fluid">
                        </div>
                        <div class="service_heading">
                            <h2>Residential Construction</h2>
                        </div>
                        <div class="service_para">
                            <p>Sense Projects is into developing Independent Houses, Bungalows, Flats, Apartments,
                                Villas, Plot layouts, Engineered Layouts with uncompromising Quality.</p>
                        </div>
                        <div class="service_arrow" data-toggle="modal" data-target="#exampleModal">
                            <i class="fa-solid fa-arrow-right"></i>
                        </div>
                    </div>
                </div>

                <div class="service-1 col-md-4 mt-lg-5 p-lg-3 text-left mb-4">
                    <div class="services_bx">
                        <div class="service_icon">
                            <img src="assets/img/Icon2.png" alt="" class="img-fluid">
                        </div>
                        <div class="service_heading">
                            <h2>Industrial Construction</h2>
                        </div>
                        <div class="service_para">
                            <p>We are service-oriented company, our process starts with a keen set of ears to best
                                understand just how you want to use your facility.</p>
                        </div>
                        <div class="service_arrow" data-toggle="modal" data-target="#exampleModal">
                            <i class="fa-solid fa-arrow-right"></i>
                        </div>
                    </div>
                </div>

                <div class="service-1 col-md-4 mt-lg-5 p-lg-3 text-left mb-4">
                    <div class="services_bx">
                        <div class="service_icon">
                            <img src="assets/img/Icon3.png" alt="" class="img-fluid">
                        </div>
                        <div class="service_heading">
                            <h2>Commercial Construction</h2>
                        </div>
                        <div class="service_para">
                            <p>Sense projects pvt. Ltd. Provides Construction and Design to handle your construction and
                                remodelling needs. We are licensed and insured commercial.</p>
                        </div>
                        <div class="service_arrow" data-toggle="modal" data-target="#exampleModal">
                            <i class="fa-solid fa-arrow-right"></i>
                        </div>
                    </div>
                </div>

                <div class="service-1 col-md-4 mt-lg-5 p-lg-3 text-left mb-4">
                    <div class="services_bx">
                        <div class="service_icon">
                            <img src="assets/img/Icon4.png" alt="" class="img-fluid">
                        </div>
                        <div class="service_heading">
                            <h2>Hospitality Construction</h2>
                        </div>
                        <div class="service_para">
                            <p>We are delivering luxurious hospitality architectures designs while realizing needs of
                                today with an explicit attention to detail. We care take of everything right from
                                planning and designing to construction.</p>
                        </div>
                        <div class="service_arrow" data-toggle="modal" data-target="#exampleModal">
                            <i class="fa-solid fa-arrow-right"></i>
                        </div>
                    </div>
                </div>

                <div class="service-1 col-md-4 mt-lg-5 p-lg-3 text-left mb-4">
                    <div class="services_bx">
                        <div class="service_icon">
                            <img src="assets/img/Icon5.png" alt="" class="img-fluid">
                        </div>
                        <div class="service_heading">
                            <h2>Institutional Construction</h2>
                        </div>
                        <div class="service_para">
                            <p>Since 2007 we are Top Warehouse Construction Company In Chennai, constructing structures
                                that fulfils a role related to healthcare, education, recreation or public works.</p>
                        </div>
                        <div class="service_arrow" data-toggle="modal" data-target="#exampleModal">
                            <i class="fa-solid fa-arrow-right"></i>
                        </div>
                    </div>
                </div>

                <div class="service-1 col-md-4 mt-lg-5 p-lg-3 text-left mb-4">
                    <div class="services_bx">
                        <div class="service_icon">
                            <img src="assets/img/Icon6.png" alt="" class="img-fluid">
                        </div>
                        <div class="service_heading">
                            <h2>Warehouse Construction</h2>
                        </div>
                        <div class="service_para">
                            <p>Sense projects pvt. Ltd. Headquartered in Delhi, awarded as best in construction
                                industry. We are responsible for all the activities from design, procurement,
                                construction to commissioning.</p>
                        </div>
                        <div class="service_arrow" data-toggle="modal" data-target="#exampleModal">
                            <i class="fa-solid fa-arrow-right"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- services section end -->
    <!-- why choose us start -->
    <section id="why_us" class="py-3 why-us">
        <div class="container mb-3">
            <div class="row mt-lg-5 mb-lg-5 ">
                <div class="col-md-6 ">
                    <img class="img-fluid" src="assets/img/Why Choose Us.jpg" alt="" class="img-fluid" id="img">
                </div>
                <div class="col-md-6">
                    <div class="why_us_content">
                        <div class="why_heading">
                            <h3> Why Are <br> People Choosing Us ?</h3>
                        </div>
                        <div class="why_para text-justify">
                            <p> When it comes to selecting the best construction company in India, we stand out as the
                                top choice. we bring a wealth of experience to the table. With years of successfully
                                completed projects under our belt, we have honed our skills and expertise to deliver
                                exceptional results. Our track record speaks for itself, showcasing our commitment to
                                excellence and client satisfaction.</p>
                        </div>
                        <div class="why_points">
                            <span><i class="fa-solid fa-circle-check"></i> &nbsp; Extensive experience and proven track
                                record of excellence.</span>
                            <span><i class="fa-solid fa-circle-check"></i> &nbsp; Open communication and collaboration
                                throughout the project.</span>
                            <span><i class="fa-solid fa-circle-check"></i> &nbsp; A skilled and dedicated team of
                                professionals.</span>
                            <span><i class="fa-solid fa-circle-check"></i> &nbsp; Up-to-date knowledge of industry
                                trends and technologies.</span>
                            <span><i class="fa-solid fa-circle-check"></i> &nbsp; Focus on client satisfaction and
                                delivering exceptional results.</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- why choose us end -->


    <!-- about section start -->
    <section id="about" class="about_us py-5">
        <div class="container mt-">
            <div class="row">
                <div class="col-md-6 ms-lg-auto">
                    <div class="about_us_bx">
                        <h2 class="about_title">About Us</h2>
                        <p class="about_para text-justify">
                            we are proud to be recognized as the premier choice for construction services across the
                            nation. Our company is driven by a passion for quality, innovation, and client satisfaction.
                            We have successfully completed a wide range of projects, including residential, commercial,
                            industrial, and infrastructure developments.

                            As the best construction company in India, we prioritize the needs and aspirations of our
                            clients. We understand that every project is unique, and we tailor our services to meet
                            specific requirements.

                            Choose the best construction company in India to bring your vision to life. We are dedicated
                            to transforming spaces, enhancing communities, and building a better future. Contact us
                            today to discuss your project and experience the excellence that sets us apart.

                        </p>
                        <a href="tel:+919319412012" class="about_btn btn">Contact Us</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- about section end -->


    <!-- complete projects section start -->
    <section id="complete_projects" class="com_pro py-5">
        <div class="container">
            <div class="row">
                <div class="col-12 mt-4">
                    <h2 class="com_projects_heading">
                        Completed Projects
                    </h2>
                </div>

                <div class="col-md-4 col-6 mt-4 mt-lg-5">
                    <img src="assets/img/1.jpg" alt="" class="img-fluid">
                </div>

                <div class="col-md-4 col-6 mt-4 mt-lg-5">
                    <img src="assets/img/2.jpg" alt="" class="img-fluid">
                </div>

                <div class="col-md-4 col-6 mt-4 mt-lg-5">
                    <img src="assets/img/3.jpg" alt="" class="img-fluid">
                </div>

                <div class="col-md-4 col-6 mt-4 mt-lg-4">
                    <img src="assets/img/4.jpg" alt="" class="img-fluid">
                </div>

                <div class="col-md-4 col-6 mt-4 mt-lg-4">
                    <img src="assets/img/5.jpg" alt="" class="img-fluid">
                </div>

                <div class="col-md-4 col-6 mt-4 mt-lg-4">
                    <img src="assets/img/6.jpg" alt="" class="img-fluid">
                </div>

                <div class="col-md-4 col-6 mt-4 mt-lg-4">
                    <img src="assets/img/7.jpg" alt="" class="img-fluid">
                </div>

                <div class="col-md-4 col-6 mt-4 mt-lg-4">
                    <img src="assets/img/8.jpg" alt="" class="img-fluid">
                </div>

                <div class="col-md-4 col-6 mt-4 mt-lg-4">
                    <img src="assets/img/9.jpg" alt="" class="img-fluid">
                </div>

            </div>
        </div>
    </section>
    <!-- complete projects section end -->

    <!-- testimonial section start -->
    <section id="tesimonial" class="py-lg-5 tesimonial">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2 class="testimonial_heading">Testimonials</h2>
                </div>
            </div>
            <div class="carousel_box">
                <div class="owl-carousel owl-theme">

                    <div class="item tesimonial_item">
                        <div class="tesimonial_box ">
                            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Rerum natus voluptates
                                aspernatur maiores, beatae odit neque deleniti. Vitae, impedit laborum.</p>
                        </div>
                    </div>

                    <div class="item tesimonial_item">
                        <div class="tesimonial_box">
                            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Rerum natus voluptates
                                aspernatur maiores, beatae odit neque deleniti. Vitae, impedit laborum.</p>
                        </div>
                    </div>

                    <div class="item tesimonial_item">
                        <div class="tesimonial_box">
                            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Rerum natus voluptates
                                aspernatur maiores, beatae odit neque deleniti. Vitae, impedit laborum.</p>
                        </div>
                    </div>

                    <div class="item tesimonial_item">
                        <div class="tesimonial_box">
                            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Rerum natus voluptates
                                aspernatur maiores, beatae odit neque deleniti. Vitae, impedit laborum.</p>
                        </div>
                    </div>

                    <div class="item tesimonial_item">
                        <div class="tesimonial_box">
                            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Rerum natus voluptates
                                aspernatur maiores, beatae odit neque deleniti. Vitae, impedit laborum.</p>
                        </div>
                    </div>

                    <div class="item tesimonial_item">
                        <div class="tesimonial_box">
                            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Rerum natus voluptates
                                aspernatur maiores, beatae odit neque deleniti. Vitae, impedit laborum.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- testimonial section end -->





    <section class="clients pt-50">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="heading-title center-title">
                        <h2>Our Clients</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div id="client-logo-slider" class="owl-carousel owl-loaded owl-drag client-logo-slider">
                    <div class="owl-stage-outer">
                        <div class="owl-stage"
                            style="transform: translate3d(-1995px, 0px, 0px); transition: all 0.6s ease 0s; width: 6840px;">
                            <div class="owl-item cloned" style="width: 285px;">
                                <div class="item">
                                    <div class="img-box">
                                        <img src="https://senseinteriors.in/assets/images/logo/client-19.png"
                                            class="img-fluid">
                                    </div>
                                    <div class="img-box">
                                        <img src="https://senseinteriors.in/assets/images/logo/client-17.png"
                                            class="img-fluid">
                                    </div>
                                </div>
                            </div>


                            <div class="owl-item" style="width: 285px;">
                                <div class="item">
                                    <div class="img-box">
                                        <img src="https://senseinteriors.in/assets/images/logo/client-14.png"
                                            class="img-fluid">
                                    </div>
                                    <div class="img-box">
                                        <img src="https://senseinteriors.in/assets/images/logo/client-08.png"
                                            class="img-fluid">
                                    </div>
                                </div>
                            </div>
                            <div class="owl-item active" style="width: 285px;">
                                <div class="item">
                                    <div class="img-box">
                                        <img src="https://senseinteriors.in/assets/images/logo/client-13.png"
                                            class="img-fluid">
                                    </div>
                                    <div class="img-box">
                                        <img src="https://senseinteriors.in/assets/images/logo/client-15.png"
                                            class="img-fluid">
                                    </div>
                                </div>
                            </div>
                            <div class="owl-item active" style="width: 285px;">
                                <div class="item">
                                    <div class="img-box">
                                        <img src="https://senseinteriors.in/assets/images/logo/client-16.png"
                                            class="img-fluid">
                                    </div>
                                    <div class="img-box">
                                        <img src="https://senseinteriors.in/assets/images/logo/client-18.png"
                                            class="img-fluid">
                                    </div>
                                </div>
                            </div>
                            <div class="owl-item active" style="width: 285px;">
                                <div class="item">
                                    <div class="img-box">
                                        <img src="https://senseinteriors.in/assets/images/logo/client-20.png"
                                            class="img-fluid">
                                    </div>
                                    <div class="img-box">
                                        <img src="https://senseinteriors.in/assets/images/logo/client-11.png"
                                            class="img-fluid">
                                    </div>
                                </div>
                            </div>
                            <div class="owl-item active" style="width: 285px;">
                                <div class="item">
                                    <div class="img-box">
                                        <img src="https://senseinteriors.in/assets/images/logo/client-22.png"
                                            class="img-fluid">
                                    </div>
                                    <div class="img-box">
                                        <img src="https://senseinteriors.in/assets/images/logo/client-24.png"
                                            class="img-fluid">
                                    </div>
                                </div>
                            </div>
                            <div class="owl-item" style="width: 285px;">
                                <div class="item">
                                    <div class="img-box">
                                        <img src="https://senseinteriors.in/assets/images/logo/client-02.png"
                                            class="img-fluid">
                                    </div>
                                    <div class="img-box">
                                        <img src="https://senseinteriors.in/assets/images/logo/client-04.png"
                                            class="img-fluid">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="owl-nav disabled"><button type="button" role="presentation" class="owl-prev"><span
                                aria-label="Previous">‹</span></button><button type="button" role="presentation"
                            class="owl-next"><span aria-label="Next">›</span></button></div>
                    <div class="owl-dots"><button role="button" class="owl-dot active"><span></span></button><button
                            role="button" class="owl-dot"><span></span></button><button role="button"
                            class="owl-dot"><span></span></button></div>
                </div>
            </div>
        </div>
    </section>




    <!-- footer section start -->
    <footer class="footer py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-4 order-1 order-lg-0 mt-3">
                    <div class="footer_left_box">
                        <div class="footer_bx_1">
                            <h2 class="footer_title">Build with SPPL</h2>
                            <p class="footer_para">Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit
                                sapiente ex voluptates in asperiores est blanditiis voluptatum doloribus officia
                                minima.</p>
                            <span class="footer_time_txt"><i class="fa-solid fa-clock"></i> &nbsp; <strong>MON - SAT
                                    &nbsp; </strong>8:00AM - 8:00PM</span>
                        </div>
                        <div class="footer_bx_2">
                            <h2 class="footer_title">Our Services</h2>
                            <span class="service_list">Civil Construction</span>
                            <span class="service_list">Pre Engineered Buildings</span>
                            <span class="service_list">Interior</span>
                            <span class="service_list">Road Services</span>
                            <span class="service_list">Collaboration</span>
                            <span class="service_list">Mechanical Electrical Plumbing</span>
                        </div>
                        <div class="footer_bx_3">
                            <h2 class="footer_title">Headquarter</h2>
                            <span class="info">DLF Prime Tower</span>
                            <span class="info">Okhla Phase 1, Delhi - 110020</span>
                            <span class="info">+ 91-9319412012</span>
                            <span class="info">info@senseprojects.in</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-7 m-auto order-0 order-lg-1">
                    <div class="footer_form">
                        <form  action="thankyou.php"   class="company_form">
                            <h3>Get In Touch</h3>
                            <!-- <h4>Contact us for custom quote</h4>       id="contact"-->
                            <fieldset>
                                <input placeholder="Your name" type="text" tabindex="1" required>
                            </fieldset>
                            <fieldset>
                                <input placeholder="Your Email Address" type="email" tabindex="2" required>
                            </fieldset>
                            <fieldset>
                                <input placeholder="Your Phone Number" type="tel" tabindex="3" required>
                            </fieldset>
                            <fieldset>
                                <textarea placeholder="Type your message here...." tabindex="6" required></textarea>
                            </fieldset>
                            <fieldset>
                                <button name="submit" type="submit"  class="appoint" id="contact-submit" data-submit="...Sending">Send
                                    Message</button>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid pt-lg-5">
            <div class="row">
                <div class="col-md-7">
                    <p class="copy_right">Complete Solution for Construction Companies in Delhi Ncr Noida, Gurgaon
                        Copyright 2004~ 2022 Sense Projects Pvt Ltd All right reserved.</p>
                </div>
                <div class="col-md-5">
                    <div class="social_icon">
                        <a href="https://www.facebook.com/senseprojects"><i class="fa-brands fa-facebook"></i></a>
                        <a href="https://twitter.com/sense_projects"><i class="fa-brands fa-twitter"></i></a>
                        <a href="https://www.linkedin.com/in/sense-project-85aa8a8b/"><i
                                class="fa-brands fa-linkedin"></i></a>
                        <a href="https://www.linkedin.com/in/sense-project-85aa8a8b/"><i
                                class="fa-brands fa-instagram"></i></a>
                        <a href="https://in.pinterest.com/senseprojects1/"><i class="fa-brands fa-pinterest"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- footer section end -->


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4"
        crossorigin="anonymous"></script>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
        crossorigin="anonymous"></script>

      

 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.3.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>

    <script type="text/javascript">
        $('.company_form').submit(function (e) {
            e.preventDefault();
            console.log("697");
            
            var formData = new FormData(this);
            $.ajax({
                url: 'mailprocess.php',
                type: 'POST',
                contentType: false,
                processData: false,
                data: formData,
                beforeSend: function () {
                    $('.appoint').attr('disabled', true);
                    $('.appoint').html('Please wait...');
                },
                success: function (data) {
                    console.log(data);
                    if (data == 1) {
                        $('.company_form').trigger('reset');
                        $("#exampleModal .close").click()
                        window.location = "thankyou.php";
                    }
                }
            }).done(function () {
                $('.appoint').attr('disabled', false);
            })

        })


        $(document).on('click', '.book_now', function () {
            var name = $(this).data('name');
            $('#exampleModalLabel').html(name);
        })
    </script>
 




    <!-- owl carousel cdn -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>

    <!-- carousel js  -->
    <script>
        $(function () {
            // Owl Carousel
            var owl = $(".owl-carousel");
            owl.owlCarousel({
                // items: 3,
                // margin: 10,
                // loop: true,
                // nav: false,
                // autoplay: true, 
                // autoplaySpeed: 500, 
                loop: true,
                autoplay: true,
                dots: true,
                autoplayTimeout: 2000,
                smartSpeed: 600,
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 2
                    },
                    1000: {
                        items: 3
                    }
                }
            });
        });
        // $(function () {
        //     // Owl Carousel
        //     var owl = $(".owl-carousel");
        //     owl.owlCarousel({
        //         items: 3,
        //         margin: 10,
        //         loop: true,
        //         nav: false,
        //         responsive: {
        //             0: {
        //                 items: 1
        //             },
        //             600: {
        //                 items: 2
        //             },
        //             1000: {
        //                 items: 3
        //             }
        //         }
        //     });
        // });
    </script>
    <script>
        $("#client-logo-slider").owlCarousel({
            loop: true,
            autoplay: true,
            dots: true,
            autoplayTimeout: 2000,
            smartSpeed: 600,
            responsive: {
                0: {
                    items: 2
                },
                600: {
                    items: 3
                },
                1000: {
                    items: 4
                }
            }
        })
    </script>
</body>

</html>

