<?php 

   $name          = $_POST['name'];
   $email         = $_POST['email'];
   $subject       = $_POST['subject'];
   $msg           = $_POST['message'];
   //date_default_timezone_set("Asia/Calcutta");
   // echo $date = date("j-n-Y");
   // echo $time = date("g:i a");
   
    //Import PHPMailer classes into the global namespace
    //These must be at the top of your script, not inside a function
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;
    
    
    require 'PHPMailer/src/Exception.php';
    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';
    //Load Composer's autoloader
    // require 'vendor/autoload.php';
    
    //Create an instance; passing `true` enables exceptions
    $mail = new PHPMailer(true);
    
    if(!empty($name) && !empty($msg) && !empty($subject) && !empty($email)) {
    //echo $name . $sub . $visitor_email . $msg . $phone ;
    
        try {
    //Server settings
    //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'mail.spplc.in';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'web@spplc.in';                     //SMTP username
    $mail->Password   = '43uSzI#+g@U0';                               //SMTP password
    //$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->SMTPSecure = 'TLS';            //Enable implicit TLS encryption
    $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('web@spplc.in', 'Gliss');
    $mail->addAddress('info@gliss.in', 'Gliss');     //Add a recipient 
    //$mail->addAddress('ellen@example.com');               //Name is optional
    $mail->addReplyTo('info@gliss.in', 'Gliss');
    //$mail->addCC('cc@example.com');
    //$mail->addBCC('bcc@example.com');

    //Attachments
    //$mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = $subject;
    $mail->Body    = "<!doctype html>
                <html lang='en-US'>
                   <head>
                      <meta content='text/html; charset=utf-8' http-equiv='Content-Type' />
                      <title>Contact Form</title>
                      <meta name='description' content='Contact Form'>
                   </head>
                   <style>
                      a:hover {text-decoration: underline !important;}
                   </style>
                   <body marginheight='0' topmargin='0' marginwidth='0' style='margin: 0px; background-color: #f2f3f8;' leftmargin='0'>
                      <table cellspacing='0' border='0' cellpadding='0' width='100%' bgcolor='#f2f3f8'
                      style='@import url(https://fonts.googleapis.com/css?family=Rubik:300,400,500,700|Open+Sans:300,400,600,700); font-family: 'Open Sans, sans-serif;'>
                      <tr>
                         <td>
                            <table style='background-color: #f2f3f8; max-width:670px; margin:0 auto;' width='100%' border='0'
                               align='center' cellpadding='0' cellspacing='0'>
                               <tr>
                                  <td style='height:50px;'>&nbsp;</td>
                               </tr>
                               <!-- Logo -->
                               <tr>
                                  <td style='text-align:center;'>
                                     <a href='https://senseprojects.in/' title='logo' target='_blank'>
                                     <img width='90' src='https://gliss.in/assets/img/logo/glissLogo.png' title='logo' alt='logo'>
                                     </a>
                                  </td>
                               </tr>
                               <tr>
                                  <td style='height:20px;'>&nbsp;</td>
                               </tr>
                               <!-- Email Content -->
                               <tr>
                                  <td>
                                     <table width='95%' border='0' align='center' cellpadding='0' cellspacing='0'
                                        style='max-width:670px; background:#fff; border-radius:3px;-webkit-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);-moz-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);box-shadow:0 6px 18px 0 rgba(0,0,0,.06);padding:0 40px;'>
                                        <tr>
                                           <td style='height:40px;'>&nbsp;</td>
                                        </tr>
                                        <!-- Title -->
                                        <tr>
                                           <td style='padding:0 15px; text-align:center;'>
                                              <h1 style='color:#1e1e2d; font-weight:300; margin:0;font-size:25px;font-family:'Rubik,sans-serif;'>{$name} contacted you <br> through website</h1>
                                              <span style='display:inline-block; vertical-align:middle; margin:29px 0 26px; border-bottom:1px solid #cecece; 
                                                 width:100px;'></span>
                                           </td>
                                        </tr>
                                        <!-- Details Table -->
                                        <tr>
                                           <td>
                                              <table cellpadding='0' cellspacing='0'
                                                 style='width: 100%; border: 1px solid #ededed'>
                                                 <tbody>
                                                    <tr>
                                                       <td
                                                          style='padding: 10px; border-bottom: 1px solid #ededed; border-right: 1px solid #ededed; width: 35%; font-weight:500; color:rgba(0,0,0,.64)'>
                                                          Name: 
                                                       </td>
                                                       <td
                                                          style='padding: 10px; border-bottom: 1px solid #ededed; color: #455056;'>
                                                          {$name}
                                                       </td>
                                                    </tr>
                                                    <tr>
                                                       <td
                                                          style='padding: 10px; border-bottom: 1px solid #ededed; border-right: 1px solid #ededed; width: 35%; font-weight:500; color:rgba(0,0,0,.64)'>
                                                          Email:
                                                       </td>
                                                       <td
                                                          style='padding: 10px; border-bottom: 1px solid #ededed; color: #455056;'>
                                                          {$email}
                                                       </td>
                                                    </tr>
                                                    <tr>
                                                       <td
                                                          style='padding: 10px; border-bottom: 1px solid #ededed;border-right: 1px solid #ededed; width: 35%; font-weight:500; color:rgba(0,0,0,.64)'>
                                                           Subject:
                                                       </td>
                                                       <td
                                                          style='padding: 10px; border-bottom: 1px solid #ededed; color: #455056;'>
                                                          {$subject}
                                                       </td>
                                                    </tr>
                                                    <tr>
                                                       <td
                                                          style='padding: 10px; border-right: 1px solid #ededed; width: 35%;font-weight:500; color:rgba(0,0,0,.64)'>
                                                          Message:
                                                       </td>
                                                       <td style='padding: 10px; color: #455056;'>{$msg}</td>
                                                    </tr>
                                                 </tbody>
                                              </table>
                                           </td>
                                        </tr>
                                        <tr>
                                           <td style='height:40px;'>&nbsp;</td>
                                        </tr>
                                     </table>
                                  </td>
                               </tr>
                               <tr>
                                  <td style='height:20px;'>&nbsp;</td>
                               </tr>
                               <tr>
                                  <td style='text-align:center;'>
                                     <p style='font-size:14px; color:#455056bd; line-height:18px; margin:0 0 0;'>&copy; <strong>Gliss</strong></p>
                                  </td>
                               </tr>
                               <tr>
                                   <td style='height: 50px'></td>
                               </tr>
                            </table>
                         </td>
                      </tr>
                      </table>
                   </body>
                </html>";
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo '1';
} catch (Exception $e) {
    echo "2";
}
        
} 
else {
    echo "<script type='text/javascript'>alert('All fields are required');</script>";
}
   

// use PHPMailer\PHPMailer\PHPMailer;
// use PHPMailer\PHPMailer\Exception;
// $name = 'Avinash';
// $email = 'abc@gmail.com';
// $message = 'bla bla';





 ?>