<!-- <section>
   <nav class="navbar navbar-expand-lg navbar-light bg-white navbar_shadow fixed-top nav_bar_sidegap">
      <div class="container-fluid pe-0 ps-0">
         <a class="navbar-brand custom_mobile_width" href="https://gliss.in/"><img src="assets/img/logo/glissLogo.png" class="w-100"></a>
         <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
         <span class="navbar-toggler-icon"></span>
         </button>
         <div class="collapse navbar-collapse bg-white" id="navbarNavDropdown">
            <ul class="navbar-nav ms-auto">
               <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="index.php">Home</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="franchise.php">Franchise</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="about.php">About Us</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="contact.php">Contact Us</a>
               </li>
            </ul>
         </div>
      </div>
   </nav>
</section> -->
<style type="text/css">
   
/* BASIC SETUP */

.page-wrapper {
  width: 100%;
    height: 71px;
    position: fixed;
    top: 0;
    left: 0;
    background: #fff;
    z-index: 999;
    display: flex;
    align-items: center;
    padding: 15px 0px;
}

.nav-wrapper {
  width: 100%;
  position: -webkit-sticky; /* Safari */
  position: sticky;
  top: 0;
  background-color: #fff;
}

/*.grad-bar {
  width: 100%;
  height: 5px;
  background: linear-gradient(-45deg, #EE7752, #E73C7E, #23A6D5, #23D5AB);
  background-size: 400% 400%;
   -webkit-animation: gradbar 15s ease infinite;
   -moz-animation: gradbar 15s ease infinite;
   animation: gradbar 15s ease infinite;
}*/

/* NAVIGATION */

.navbar {
  display: grid;
  grid-template-columns: 1fr 3fr;
  align-items: center;
  /*height: 50px;*/
  /*overflow: hidden;*/
}

.navbar img {
  margin-left: 20px;
}

.navbar ul {
  list-style: none;
  /*display: grid;
  grid-template-columns: repeat(6,1fr);*/
  justify-self: end;
  align-items: center;
  
}

.nav-item a {
  color: #000;
  font-size: 0.9rem;
  font-weight: 400;
  text-decoration: none;
  transition: color 0.3s ease-out;
  margin-right: 15px;
}

.nav-item a:hover {
  color: #3498db;
}

/* SECTIONS */

.headline {
  width: 100%;
  height: 50vh;
  min-height: 350px;
  background: linear-gradient(rgba(0,0,0,0.3),rgba(0,0,0,0.7)), url('https://images.unsplash.com/photo-1435224668334-0f82ec57b605?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1yZWxhdGVkfDd8fHxlbnwwfHx8fA%3D%3D&w=1000&q=80');
  background-size: cover;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.features {
  width: 100%;
  height: auto;
  background-color: #f1f1f1;
  display: flex;
  padding: 50px 20px;
  justify-content: space-around;
}

.feature-container {
  flex-basis: 30%;
  margin-top: 10px;
}

.feature-container p {
  color: #000;
  text-align: center;
  line-height: 1.4;
  margin-bottom: 15px;
}

.feature-container img {
  width: 100%;
  margin-bottom: 15px;
}

/* SEARCH FUNCTION */


.no-search {
  transform: translate(0);
  transition: transform 0.3s ease-in-out;
}

.search-active {
  opacity: 1;
  z-index: 0;
}

input {
  border: 0;
  border-left: 1px solid #ccc;
  border-radius: 0; /* FOR SAFARI */
  outline: 0;
  padding: 5px;
}

/* MOBILE MENU & ANIMATION */

.menu-toggle .bar{
  width: 25px;
  height: 3px;
  background-color: #3f3f3f;
  margin: 5px auto;
  -webkit-transition: all 0.3s ease-in-out;
  -o-transition: all 0.3s ease-in-out;
  transition: all 0.3s ease-in-out;
}

.menu-toggle {
  justify-self: end;
  margin-right: 25px;
  display: none;
}

.menu-toggle:hover{
  cursor: pointer;
}

#mobile-menu.is-active .bar:nth-child(2){
  opacity: 0;
}

#mobile-menu.is-active .bar:nth-child(1){
  -webkit-transform: translateY(8px) rotate(45deg);
  -ms-transform: translateY(8px) rotate(45deg);
  -o-transform: translateY(8px) rotate(45deg);
  transform: translateY(8px) rotate(45deg);
}

#mobile-menu.is-active .bar:nth-child(3){
  -webkit-transform: translateY(-8px) rotate(-45deg);
  -ms-transform: translateY(-8px) rotate(-45deg);
  -o-transform: translateY(-8px) rotate(-45deg);
  transform: translateY(-8px) rotate(-45deg);
}

/* KEYFRAME ANIMATIONS */

@-webkit-keyframes gradbar {
   0% {
      background-position: 0% 50%
   }
   50% {
      background-position: 100% 50%
   }
   100% {
      background-position: 0% 50%
   }
}

@-moz-keyframes gradbar {
   0% {
      background-position: 0% 50%
   }
   50% {
      background-position: 100% 50%
   }
   100% {
      background-position: 0% 50%
   }
}

@keyframes gradbar {
   0% {
      background-position: 0% 50%
   }
   50% {
      background-position: 100% 50%
   }
   100% {
      background-position: 0% 50%
   }
}

/* Media Queries */

  /* Mobile Devices - Phones/Tablets */

@media only screen and (max-width: 720px) { 
  .features {
    flex-direction: column;
    padding: 50px;
  }
  
  /* MOBILE NAVIGATION */
     
  .navbar ul {
    display: flex;
    flex-direction: column;
    position: fixed;
    justify-content: start;
    top: 55px;
    background-color: #fff;
    width: 100%;
    height: calc(100vh - 55px);
    transform: translate(-101%);
    text-align: center;
    overflow: hidden;
  }
  
  .navbar li {
    padding: 7px;
  }
  
  .navbar li:first-child {
    margin-top: 50px;
  }
  
  .navbar li a {
    font-size: 1rem;
  }
   
  .menu-toggle, .bar {
    display: block;
    cursor: pointer;
  }
  
  .mobile-nav {
  transform: translate(0%)!important;
}
  
  /* SECTIONS */
  
  .headline {
    height: 20vh;
  }
    
  .feature-container p {
    margin-bottom: 25px;
  }
  
  .feature-container {
    margin-top: 20px;
  }
  
  .feature-container:nth-child(2) {
    order: -1;
  }
  
}
</style>
<div class="page-wrapper navbar_shadow">
 <div class="nav-wrapper">
  <!-- <div class="grad-bar"></div> -->
  <nav class="navbar">
    <a class="navbar-brand custom_mobile_width" href="https://gliss.in/"><img src="https://gliss.in/assets/img/logo/glissLogo.png" class="w-100"></a>
    <div class="menu-toggle" id="mobile-menu">
      <span class="bar"></span>
      <span class="bar"></span>
      <span class="bar"></span>
    </div>
    <ul class="nav no-search">
      <li class="nav-item"><a href="https://gliss.in/">Home</a></li>
      <li class="nav-item dropdown d-lg-block d-md-block d-sm-none d-none">
       <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="javascript:void(0)" role="button" aria-expanded="false">Services</a>
       <ul class="dropdown-menu hide_in_mobile_dropdown">
         <li><a class="dropdown-item" href="https://gliss.in/service-male">Men</a></li>
         <li><a class="dropdown-item" href="https://gliss.in/service-female">Women</a></li>
       </ul>
      </li>
      <li class="nav-item dropdown d-lg-none d-md-none d-sm-block d-block">
          <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="javascript:void(0)" role="button" aria-expanded="false">Services</a>
          <li class="d-lg-none d-md-none d-sm-block d-block"><a class="text-secondary" href="service-male">Men</a></li>
          <li class="d-lg-none d-md-none d-sm-block d-block"><a class="text-secondary" href="service-female">Women</a></li>
      </li>
      <li class="nav-item"><a href="https://gliss.in/about">About Us</a></li>
      <li class="nav-item"><a href="https://gliss.in/franchise">Franchise</a></li>
      <li class="nav-item"><a href="https://gliss.in/contact">Contact Us</a></li>
      <li class="nav-item"><a href="https://twitter.com/glissindia" class="footer_black social-menu-header" target="blank"><i class="bi bi-twitter"></i></a></li>
      <li class="nav-item"><a href="https://www.instagram.com/glissindia/" class="footer_black social-menu-header" target="blank"><i class="bi bi-instagram"></i></a></li>
      <li class="nav-item"><a href="https://www.facebook.com/glissindia" class="footer_black social-menu-header" target="blank"><i class="bi bi-facebook"></i></a></li>
      <li class="nav-item"><a href="https://www.youtube.com/@glissindia" class="footer_black social-menu-header" target="blank"><i class="bi bi-youtube"></i></a></li>
      <li class="nav-item"><a href="https://www.pinterest.com/Glissindia/" class="footer_black social-menu-header" target="blank"><i class="bi bi-pinterest"></i></a></li>
    </ul>
  </nav>
  </div>
  
</div>
<div class="nav_fixed_top"></div>