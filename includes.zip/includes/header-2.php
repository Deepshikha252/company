<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="google-site-verification" content="-sSI6lQS6sb3WHwZ3ukgMBu755LP2F6cROcSECggV0I" />
<link rel="stylesheet" type="text/css" href="../libraries/bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="../assets/css/main.css">
<link rel="stylesheet" type="text/css" href="../assets/css/style.css">
<link rel="shortcut icon" href="../assets/img/logo/logo.png">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">



