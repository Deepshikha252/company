<footer class="footer bg-ebony-clay dark-mode-texts pt-5 pb-5">
      <div class="container pt-12 pt-lg-19 pb-10 pb-lg-19">
        <div class="row mb-4">
          <div class="col-lg-4 col-sm-6 mb-lg-0 mb-9 footer_side_border">
            <img src="assets/img/logo/glissLogo.png" alt="" class="footer-logo mb-3">
            <p class="text-litegray font-ftr-bold"> Gliss always wants to assure the more trusted and branded quality products to its customers. It quickly responds to give the user friendly and more reliable information to its users and customers.</p>
          </div>
          <div class="col-lg-8 col-md-6">
            <div class="row">
              <div class="col-lg-4 col-md-6 col-sm-3 col-xs-6 footer_side_border">
                <div class="footer-widget widget2 mb-md-0 mb-13">
                  <p class=" mb-md-8">Company</p>
                  <ul class="widget-links pl-0 list-unstyled">
                    <li class="mb-2"><a class="font-ftr-bold text-litegray link" href="https://gliss.in/subscription">Buy Subscription</a></li>
                    <li class="mb-2"><a class="font-ftr-bold text-litegray link" href="https://gliss.in/contact">Get in touch</a></li>
                    <li class="mb-2"><a class="font-ftr-bold text-litegray link" href="https://gliss.in/franchise">Franchise Enquiry</a></li>
                    <li class="mb-2"><a class="font-ftr-bold text-litegray link" href="https://gliss.in/service-male">Explore Services</a></li>
                  </ul>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 col-sm-3 col-xs-6">
                <div class="footer-widget widget4">
                  <p class=" mb-md-8">Legal</p>
                  <ul class="widget-links pl-0 list-unstyled list-hover-primary">
                    <li class="mb-2"><a class="font-ftr-bold text-litegray link" href="https://gliss.in/privacy-policy">Privacy Policy</a></li>
                    <li class="mb-2"><a class="font-ftr-bold text-litegray link" href="https://gliss.in/terms-and-condition">Terms and Condition</a></li>
                  </ul>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 col-sm-3 col-xs-6">
                <!-- <div class="mt-8"> -->
                <p class="mb-md-8 mb-7">Contact Information</p>
                 <h3 class=""></h3>
                 <div class="media mb-2">
                   <div class="mr-6">
                     <i class="fas fa-map-marker-alt mt-2"></i>
                   </div>
                   <p class="mb-0 font-3 text-litegray">For any assistance please contact</p>
                 </div>
                 <div class="media mb-2">
                   <div class="mr-6">
                     <i class="fas fa-phone-alt mt-2"></i>
                   </div>
                   <p class="mb-0 font-ftr-bold"><a href="tel:01204134403" class="text-litegray"><i class="bi bi-telephone"></i>&nbsp; 01204134403</a></p>
                 </div>
                 <div class="media mb-2">
                   <div class="mr-6">
                     <i class="fas fa-phone-alt mt-2"></i>
                   </div>
                   <p class="mb-0 font-ftr-bold"><a href="tel:9667022241" class="text-litegray"><i class="bi bi-phone"></i>&nbsp; 91-9667022241</a></p>
                 </div>
                 <div class="media mb-2">
                   <div class="mr-6">
                     <i class="fas fa-envelope mt-2"></i>
                   </div>
                   <p class="mb-0"><a class="text-litegray font-ftr-bold" href="mailto:info@gliss.in"><i class="bi bi-envelope"></i>&nbsp; info@gliss.in</a></p>
                 </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row mb-4">
          <div class="col-12">
            <div class="d-flex align-items-center justify-content-around foote_badge">
              <span class="main_footer_badge"><i class="bi bi-shield-fill-check text-primary footer_secure"></i><span class="footer_badge_lable">Safe and Secure Transactions</span></span>
              <span class="main_footer_badge"><i class="bi bi-patch-check-fill text-success footer_secure"></i><span class="footer_badge_lable">Genuine products</span></span>
              <span class="main_footer_badge"><i class="bi bi-people-fill text-warning footer_secure"></i> <span class="footer_badge_lable">Skilled Professionals</span></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <div class="social-icons">
              <div class="folow_us">
                <h6 class="text-litegray text-center">Social Media Links:</h6>
              </div>
              <div class="social-menu">
                  <ul>
                      <li><a href="https://twitter.com/glissindia" class="footer_twitter" target="blank"><i class="bi bi-twitter"></i></a></li>
                      <li><a href="https://www.instagram.com/glissindia/" class="footer_insta" target="blank"><i class="bi bi-instagram"></i></a></li>
                      <li><a href="https://www.facebook.com/glissindia" class="footer_face" target="blank"><i class="bi bi-facebook"></i></a></li>
                      <li><a href="https://www.youtube.com/@glissindia" class="footer_youtube" target="blank"><i class="bi bi-youtube"></i></a></li>
                      <li><a href="https://www.pinterest.com/Glissindia/" class="footer_pintrest" target="blank"><i class="bi bi-pinterest"></i></a></li>
                      <li><a href="https://wa.me/919667022241" target="_blank" class="footer_whats" ><i class="bi bi-whatsapp"></i></a></li>
                  </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <footer class="pt-3 pb-3 bg-ebony-clay-2">
      <div class="container">
        <div class="row">
          <div class="col-6">
            <p class="font-2 mb-0 text-start text-litegray"><a href="disclaimer" class="text-litegray text-decoration-none">Disclaimer</a> | <a href="privacy-policy" class="text-litegray text-decoration-none">Privacy & Policy</a> | <a href="return-and-refund-policy" class="text-litegray text-decoration-none">Return & Refund Policy</a> | <a href="terms-and-condition" class="text-litegray text-decoration-none">Terms & Condition</a></p>
          </div>
          <div class="col-6">
            <p class="font-2 mb-0 text-end text-litegray">2022 All Right Reserved</p>
          </div>
        </div>
      </div>
    </footer>
    <div class="float_links">
      <!-- <div class="text-center"><a href="shop" class="cart_float"><i class="bi bi-cart-fill"></i></a></div> -->
      <div><a href="https://wa.me/919667022241" target="_blank" class="chat_permalink">
        <svg width="40" viewBox="0 0 24 24"><defs></defs><path fill="#eceff1" d="M20.5 3.4A12.1 12.1 0 0012 0 12 12 0 001.7 17.8L0 24l6.3-1.7c2.8 1.5 5 1.4 5.8 1.5a12 12 0 008.4-20.3z"></path><path fill="#4caf50" d="M12 21.8c-3.1 0-5.2-1.6-5.4-1.6l-3.7 1 1-3.7-.3-.4A9.9 9.9 0 012.1 12a10 10 0 0117-7 9.9 9.9 0 01-7 16.9z"></path><path fill="#fafafa" d="M17.5 14.3c-.3 0-1.8-.8-2-.9-.7-.2-.5 0-1.7 1.3-.1.2-.3.2-.6.1s-1.3-.5-2.4-1.5a9 9 0 01-1.7-2c-.3-.6.4-.6 1-1.7l-.1-.5-1-2.2c-.2-.6-.4-.5-.6-.5-.6 0-1 0-1.4.3-1.6 1.8-1.2 3.6.2 5.6 2.7 3.5 4.2 4.2 6.8 5 .7.3 1.4.3 1.9.2.6 0 1.7-.7 2-1.4.3-.7.3-1.3.2-1.4-.1-.2-.3-.3-.6-.4z"></path></svg>
        <!--<span class="chat_us">Chat with us</span>--></a></div>
    </div>

