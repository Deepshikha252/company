<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="https://gliss.in/assets/img/logo/logo.png">
    <title>academy || Hair Dressing</title>


    <!-- header CDN links -->
    <?php include '../includes/header-2.php' ?>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <!-- navigation bar -->
    <?php include '../includes/navbar.php' ?>
    <!-- banner start -->
    <section id="banner" class="coursebanner">
        <div class="container">
            <div class="row">
                <div class="col text-center">
                    <h1 class="form-title">HAIR DRESSIGN</h1>
                    <h4>Advance Cut and Color is a modern approach to hairstyling that focuses on creating shapes and textures. It marries classic cutting techniques with creative coloring methods, relying on the use of scissors, clippers, razors, highlights, and balayage to create a bespoke hairstyle. </h4>
                </div>
            </div>
        </div>
    </section>
    <!-- banner ends -->

    <!-- course card start -->
    <section id="coursecard" class="coursecard">
        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-md-6">
                    <div class="price-card">
                        <div class="price-card__header">
                            <h3 class="price-card__title"> Eligibility</h3>
                        </div>
                         <p class="price-card__text">You should be passionate about hair & have a flair for fashion.</p>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6">
                    <div class="price-card">
                        <div class="price-card__header">
                            <h3 class="price-card__title"> Courses Content</h3>

                        </div>
                         <p class="price-card__text">Hair Science, Hair Care, Texture, Shampooing, Styling, Consultatation, Classic cut, Classic color, ADvacned hait cut, Advanceed ahir color, Communications, Scalp Series, Men's hair cut & Long hair styling.</p>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="price-card">
                        <div class="price-card__header">
                            <h3 class="price-card__title"> Course Duration</h3>
                        </div>
                         <p class="price-card__text">3.5 Months (Six days a week)</p>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="price-card">
                        <div class="price-card__header">
                            <h3 class="price-card__title"> Ceritification</h3>
                        </div>
                         <p class="price-card__text">On completion of the course you will receive the Certificate from Looks School of Hair and Beauty</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- course card end -->



    <!-- contact  start -->
    <section id="contact" class="contact">
        <div class="container">
            <div class="row">
                <div class="col-md-5 mb-4">
                    <img src="assets/images/contact-shape-1-1.png" alt="" class="img-fluid">
                </div>
                <div class="col-md-7">
                    <form action="mail.php" method="POST" class="ajax-contact form-style3">
                        <h3 class="form-title">Quick Contact</h3>
                        <div class="row gx-20">
                            <div class="form-group col-md-6"><input type="text" name="name" id="name" placeholder="Enter Name"> <i class="bi bi-person"></i></div>
                            <div class="form-group col-md-6"><input type="email" name="email" id="email" placeholder="Email Address"><i class="bi bi-envelope"></i> </div>
                            <div class="form-group col-12"><select name="subject" id="subject">
                                    <option value="" disabled="disabled" hidden="">Select Course</option>
                                    <option value="Makeup">Makeup</option>
                                    <option value="Classic Cut">Classic Cut</option>
                                    <option value="Men's Hair Dressing">Men's Hair Dressing</option>
                                    <option value="Advance Cut & Color">Advance Cut & Color</option>
                                    <option value="Hair Dressing" selected="selected">Hair Dressing</option>
                                    <option value="Salon Essential">Salon Essential </option>
                                    <option value=" Nail Art"> Nail Art</option>
                                    <option value="Long Hair Dressing "> Long Hair Dressing</option>
                                </select> <i class="bi bi-check-all"></i></div>
                            <div class="form-group col-12"><textarea name="message" id="message" cols="30" rows="3" placeholder="Message here"></textarea> <i class="bi bi-chat"></i></div>
                            <div class="form-btn col-12"><button type="submit" class="btn btn-md btn-success ">Submit Now<i class="bi bi-arrow-right"></i></button></div>
                        </div>
                        <p class="form-messages mb-0 mt-3"></p>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- contact  ends -->


    <!-- footer -->
    <?php include '../includes/footer.php' ?>

    <!-- footer links  -->
    <?php include "../includes/footer_script-2.php"; ?>
</body>

</html>