<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="https://gliss.in/assets/img/logo/logo.png">
    <title>academy || makeup</title>


    <!-- header CDN links -->
    <?php include '../includes/header-2.php' ?>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <!-- navigation bar -->
    <?php include '../includes/navbar.php' ?>
    <!-- banner start -->
    <section id="banner" class="coursebanner">
        <div class="container">
            <div class="row">
                <div class="col text-center">
                    <h1 class="form-title">ART OF MAKEUP</h1>
                    <h4>Are you looking for  Makeup educational opportunities ?
                        <br> If so, you have come to the right place! Gliss Makeup academy provide a unique and comprehensive education for aspiring makeup artists and professionals. </h4>
                </div>
            </div>
        </div>
    </section>
    <!-- banner ends -->

    <!-- course card start -->
    <section id="coursecard" class="coursecard">
        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-md-6">
                    <div class="price-card">
                        <div class="price-card__header">
                            <h3 class="price-card__title"> Eligibility</h3>
                        </div>
                        <p class="price-card__text">Firstly, the applicant must have a high school diploma or equivalent to demonstrate that they have a basic level of education and knowledge.</p>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6">
                    <div class="price-card">
                        <div class="price-card__header">
                            <h3 class="price-card__title"> Courses Content</h3>

                        </div>
                        <p class="price-card__text">Foundation of classic long hair dressing techniques, bridal runaway and editorial looks. Deomonstration and practical. </p>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="price-card">
                        <div class="price-card__header">
                            <h3 class="price-card__title"> Course Duration</h3>
                        </div>
                        <p class="price-card__text">One Year </p>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="price-card">
                        <div class="price-card__header">
                            <h3 class="price-card__title"> Ceritification</h3>
                        </div>
                        <p class="price-card__text">On completion of the course you will receive the Certificate from the Looks School of Hair and Beauty.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- course card end -->



    <!-- contact  start -->
    <section id="contact" class="contact">
        <div class="container">
            <div class="row">
                <div class="col-md-5 mb-4">
                    <img src="assets/images/contact-shape-1-1.png" alt="" class="img-fluid">
                </div>
                <div class="col-md-7">
                    <form action="mail.php" method="POST" class="ajax-contact form-style3">
                        <h3 class="form-title">Quick Contact</h3>
                        <div class="row gx-20">
                            <div class="form-group col-md-6"><input type="text" name="name" id="name" placeholder="Enter Name"> <i class="bi bi-person"></i></div>
                            <div class="form-group col-md-6"><input type="email" name="email" id="email" placeholder="Email Address"><i class="bi bi-envelope"></i> </div>
                            <div class="form-group col-12"><select name="subject" id="subject">
                                    <option value="" disabled="disabled" hidden="">Select Course</option>
                                    <option value="Makeup" selected="selected">Makeup</option>
                                    <option value="Classic Cut">Classic Cut</option>
                                    <option value="Men's Hair Dressing">Men's Hair Dressing</option>
                                    <option value="Advance Cut & Color">Advance Cut & Color</option>
                                    <option value="Hair Dressing">Hair Dressing</option>
                                    <option value="Salon Essential">Salon Essential </option>
                                    <option value=" Nail Art"> Nail Art</option>
                                    <option value="Long Hair Dressing "> Long Hair Dressing</option>
                                </select> <i class="bi bi-check-all"></i></div>
                            <div class="form-group col-12"><textarea name="message" id="message" cols="30" rows="3" placeholder="Message here"></textarea> <i class="bi bi-chat"></i></div>
                            <div class="form-btn col-12"><button type="submit" class="btn btn-md btn-success ">Submit Now<i class="bi bi-arrow-right"></i></button></div>
                        </div>
                        <p class="form-messages mb-0 mt-3"></p>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- contact  ends -->


    <!-- footer -->
    <?php include '../includes/footer.php' ?>

    <!-- footer links  -->
    <?php include "../includes/footer_script-2.php"; ?>
</body>

</html>