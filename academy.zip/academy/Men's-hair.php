<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="https://gliss.in/assets/img/logo/logo.png">
    <title>academy || Men's Hair Dressing</title>


    <!-- header CDN links -->
    <?php include '../includes/header-2.php' ?>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <!-- navigation bar -->
    <?php include '../includes/navbar.php' ?>
    <!-- banner start -->
    <section id="banner" class="coursebanner">
        <div class="container">
            <div class="row">
                <div class="col text-center">
                    <h1 class="form-title">MEN'S HAIR DRESSING</h1>
                    <h4>When it comes to men's hair styling, there are many options available. From classic comb-overs to modern buzzcuts, you can choose the style that best suits your face shape and hairstyle. To achieve the desired look, it is important to invest in quality products, such as shampoo, conditioner, and hair styling products. </h4>
                </div>
            </div>
        </div>
    </section>
    <!-- banner ends -->

     <!-- course card start -->
     <section id="coursecard" class="coursecard">
        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-md-6">
                    <div class="price-card">
                        <div class="price-card__header">
                            <h3 class="price-card__title"> Eligibility</h3>
                        </div>
                        <p class="price-card__text">Furthermore, students should have a good eye for detail and be knowledgeable about the different types of hair cutting techniques. Those wishing to pursue a long-term career in the field should have a portfolio of work to demonstrate their proficiency.  </p>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6">
                    <div class="price-card">
                        <div class="price-card__header">
                            <h3 class="price-card__title"> Courses Content</h3>

                        </div>
                        <p class="price-card__text">Classic & advanced techeniques to achieve tailor made haircut. Demonstration & practical.</p>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="price-card">
                        <div class="price-card__header">
                            <h3 class="price-card__title"> Course Duration</h3>
                        </div>
                        <p class="price-card__text">Five Days</p>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="price-card">
                        <div class="price-card__header">
                            <h3 class="price-card__title"> Ceritification</h3>
                        </div>
                        <p class="price-card__text">On completion of the course you will receive the Certificate from Looks School of Hair and Beauty</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- course card end -->



    <!-- contact  start -->
    <section id="contact" class="contact">
        <div class="container">
            <div class="row">
                <div class="col-md-5 mb-4">
                    <img src="assets/images/contact-shape-1-1.png" alt="" class="img-fluid">
                </div>
                <div class="col-md-7">
                    <form action="mail.php" method="POST" class="ajax-contact form-style3">
                        <h3 class="form-title">Quick Contact</h3>
                        <div class="row gx-20">
                            <div class="form-group col-md-6"><input type="text" name="name" id="name" placeholder="Enter Name"> <i class="bi bi-person"></i></div>
                            <div class="form-group col-md-6"><input type="email" name="email" id="email" placeholder="Email Address"><i class="bi bi-envelope"></i> </div>
                            <div class="form-group col-12"><select name="subject" id="subject">
                                    <option value="" disabled="disabled" selected="selected" hidden="">Select Service</option>
                                    <option value="Web Development">Web Development</option>
                                    <option value="Brand Marketing">Brand Marketing</option>
                                    <option value="UI/UX Designing">UI/UX Designing</option>
                                    <option value="Digital Marketing">Digital Marketing</option>
                                </select> <i class="bi bi-check-all"></i></div>
                            <div class="form-group col-12"><textarea name="message" id="message" cols="30" rows="3" placeholder="Message here"></textarea> <i class="bi bi-chat"></i></div>
                            <div class="form-btn col-12"><button type="submit" class="btn btn-md btn-success ">Submit Now<i class="bi bi-arrow-right"></i></button></div>
                        </div>
                        <p class="form-messages mb-0 mt-3"></p>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- contact  ends -->


    <!-- footer -->
    <?php include '../includes/footer.php' ?>

    <!-- footer links  -->
    <?php include "../includes/footer_script-2.php"; ?>
</body>

</html>