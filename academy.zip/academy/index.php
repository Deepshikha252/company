<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="https://gliss.in/assets/img/logo/logo.png">
    <title>gliss || academy</title>


    <!-- header CDN links -->
    <?php include '../includes/header-2.php' ?>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <!-- navigation bar -->
    <?php include '../includes/navbar.php' ?>

    <section id="banner" class="banner">
        <div class="container">
            <div class="row">
                <div class="col text-center">
                    <h2>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Laudantium suscipit sint mollitia voluptatum ipsam, nam quo veritatis nulla, necessitatibus saepe, autem ab. Nihil.</h2>
                </div>
            </div>
        </div>
    </section>

    <section id="hero" class="hero">
        <div class="container">
            <div class="row">
                <div class="col-md-5 order-1">
                    <div class="left-txt-container">
                        <div class="title-area mb-3">
                            <span class="subtitle">UNLIMITED ONLINE SHOP</span>
                            <h2 class="sec-title">E-commerce Included</h2>
                        </div>

                        <p class="mb-0 para">We always think about user perfection. So that we are producing a dynamic contact form with ajax. So that you can easily set up your website and get response from the visitors.</p>

                    </div>
                </div>
                <div class="col-md-7 order-0 mb-3">
                    <img src="assets/images/feature-1.png" alt="" class="img-fluid">
                </div>
            </div>
        </div>
    </section>

    <!-- contact working section -->
    <section id="workingcontact" class="contact">
        <div class="container">
            <div class="row">
                <div class="col-md-7 mb-4">
                    <img src="assets/images/feature-2.png" alt="" class="img-fluid">
                </div>
                <div class="col-md-5">
                    <div class="left-txt-container">
                        <div class="title-area mb-3">
                            <span class="subtitle">WORKING CONTACT FORM</span>
                            <h2 class="sec-title">Contact Form With Ajax</h2>
                        </div>
                        <p class="mb-0 para">We always think about user perfection. So that we are producing a dynamic contact form with ajax. So that you can easily set up your website and get response from the visitors.</p>
                        <div class="contact_btn mt-5">
                            <a href="#contact" class="btn btn-dark py-2 px-4">Contact Us</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- contact working ends -->


    <!-- course start -->
    <section id="course" class="course">
        <div class="container">
            <div class="title-area text-center">
                <h2 class="sec-title">Awesome Features</h2>
                <p class="sec-text">This template is build with all modern and latest feature. <br>Developer can easily handle this.</p>
            </div>
            <div class="row">
                <div class="col-md-3 col-sm-6 col-6  feature-grid">
                    <a href="makeup.php">
                        <div class="feature-grid_icon">
                            <img src="assets/images/makeup.svg" alt="icon">
                        </div>
                        <h4 class="feature-grid_title">Makeup</h4>
                    </a>
                </div>
                <div class="col-md-3 col-sm-6 col-6  feature-grid">
                    <a href="classic-cut.php">
                        <div class="feature-grid_icon">
                            <img src="assets/images/Classic Cut.svg" alt="icon">
                        </div>
                        <h4 class="feature-grid_title">Classic Cut</h4>
                    </a>
                </div>
                <div class="col-md-3 col-sm-6 col-6  feature-grid">
                    <a href="Men's-hair.php">
                        <div class="feature-grid_icon">
                            <img src="assets/images/Men's Hair Dressing.svg" alt="icon">
                        </div>
                        <h4 class="feature-grid_title">Men's Hair Dressing</h4>
                    </a>
                </div>
                <div class="col-md-3 col-sm-6 col-6  feature-grid">
                    <a href="Advance-cutcolor.php">
                        <div class="feature-grid_icon">
                            <img src="assets/images/Advance Cut & Color.svg" alt="icon">
                        </div>
                        <h4 class="feature-grid_title">Advance Cut & Color</h4>
                    </a>
                </div>



                <div class="col-md-3 col-sm-6 col-6  feature-grid">
                    <a href="hair-dressing.php">
                        <div class="feature-grid_icon">
                            <img src="assets/images/Hair Dressing.svg" alt="icon">
                        </div>
                        <h4 class="feature-grid_title">Hair Dressing</h4>
                    </a>
                </div>
                <div class="col-md-3 col-sm-6 col-6  feature-grid">
                    <a href="salon-essential.php">
                        <div class="feature-grid_icon">
                            <img src="assets/images/Salon Essential.svg" alt="icon">
                        </div>
                        <h4 class="feature-grid_title">Salon Essential</h4>
                    </a>
                </div>
                <div class="col-md-3 col-sm-6 col-6  feature-grid">
                    <a href="nail-art.php">
                        <div class="feature-grid_icon nail">
                            <img src="assets/images/Nail Art.svg" alt="icon">
                        </div>
                        <h4 class="feature-grid_title">Nail Art</h4>
                    </a>
                </div>
                <div class="col-md-3 col-sm-6 col-6  feature-grid">
                    <a href="long-hair.php">
                        <div class="feature-grid_icon">
                            <img src="assets/images/Long Hair.svg" alt="icon">
                        </div>
                        <h4 class="feature-grid_title">Long Hair Dressing</h4>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <!-- course ends -->

    <!-- contact  start -->
    <section id="contact" class="contact">
        <div class="container">
            <div class="row">
                <div class="col-md-5 mb-4">
                    <img src="assets/images/contact-shape-1-1.png" alt="" class="img-fluid">
                </div>
                <div class="col-md-7">
                    <form action="mail.php" method="POST" class="ajax-contact form-style3">
                        <h3 class="form-title">Quick Contact</h3>
                        <div class="row gx-20">
                            <div class="form-group col-md-6"><input type="text" name="name" id="name" placeholder="Enter Name"> <i class="bi bi-person"></i></div>
                            <div class="form-group col-md-6"><input type="email" name="email" id="email" placeholder="Email Address"><i class="bi bi-envelope"></i> </div>
                            <div class="form-group col-12"><select name="subject" id="subject">
                                    <option value="" disabled="disabled" selected="selected" hidden="">Select Course</option>
                                    <option value="Makeup">Makeup</option>
                                    <option value="Classic Cut">Classic Cut</option>
                                    <option value="Men's Hair Dressing">Men's Hair Dressing</option>
                                    <option value="Advance Cut & Color">Advance Cut & Color</option>
                                    <option value="Hair Dressing">Hair Dressing</option>
                                    <option value="Salon Essential">Salon Essential </option>
                                    <option value=" Nail Art"> Nail Art</option>
                                    <option value="Long Hair Dressing "> Long Hair Dressing</option>
                                </select> <i class="bi bi-check-all"></i></div>
                            <div class="form-group col-12"><textarea name="message" id="message" cols="30" rows="3" placeholder="Message here"></textarea> <i class="bi bi-chat"></i></div>
                            <div class="form-btn col-12"><button type="submit" class="btn btn-md btn-success ">Submit Now<i class="bi bi-arrow-right"></i></button></div>
                        </div>
                        <p class="form-messages mb-0 mt-3"></p>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- contact  ends -->


    <!-- footer -->
    <?php include '../includes/footer.php' ?>

    <!-- footer links  -->
    <?php include "../includes/footer_script-2.php"; ?>
</body>

</html>