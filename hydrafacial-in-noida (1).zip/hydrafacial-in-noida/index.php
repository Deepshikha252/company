<!Doctype html>
<html lang="en">

    <head>
        
        
 <!-- header CDN links -->
      <?php include 'includes/header.php'?>
      <!-- header CDN links -->
      
      
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="https://gliss.in/assets/img/logo/logo.png">

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

        <!-- css file -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- font awesome icon link -->
        <script src="https://kit.fontawesome.com/ed6360e682.js" crossorigin="anonymous"></script>

        <!-- google font -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link
            href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
            rel="stylesheet">

        <!-- font awesome icon link -->
        <script src="https://kit.fontawesome.com/327cf3a5b0.js" crossorigin="anonymous"></script>

        <!-- Owl Carousel -->
        <!-- ----------------------------------------------------------------------------------- -->
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" />
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
        <!-- ----------------------------------------------------------------------------------- -->

        <title>Laser Hair Removal: The Permanent Hair Reduction Solution</title>

        <meta name="description"
            content="Our laser hair removal services can help you achieve the smooth skin you've always wanted! We offer treatments for full body, full face, bikini, chest, full legs, and underarms." />


    </head>

    <body>
        
        
<!-- navigation bar -->
      <?php include 'includes/navbar.php'?>
      <!-- navigation bar -->
      

        <!-- modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content modal_bg">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Get In Touch With Us</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="company_form">
                            <div class="mb-3">
                                <label for="name" class="col-form-label">Name</label>
                                <input type="name" class="form-control" id="name" name="name"
                                    placeholder="Enter your Name" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="col-form-label">Phone</label>
                                <input type="tel" class="form-control" id="phone" name="phone"
                                    placeholder="Enter your phone" required>
                            </div>
                            <label for="select" class="col-form-label">Select Treatment</label>
                            <select class="form-select" aria-label="Default select example" name="treatment"
                                id="treatment" required>
                                <option selected>Options</option>
                                <option value="Hydra Facial" data-id='Hydra Facial'>Hydra Facial</option>
                                <option value="Carbon Facial" data-id='Carbon Facial'>Carbon Facial</option>
                                <option value="Vampire Facial" data-id='Vampire Facial'>Vampire Facial
                                </option>
                                <option value="Skin Lighting Facial" data-id='Skin Lighting Facial'>Skin
                                    Lighting Facial
                                </option>
                            </select>
                            <br>
                            <button type="submit" class="btn btn-dark appoint">Send message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
       >
                </div>
            </div>
        </section> -->

        <?php include './includes/navbar.php'; ?> 

<?php include './includes/e-nav.php'; ?>

        <section class="hero mhero ">
            <div class="container h-100">
                <div class="row h-100 position-relative">
                    <div class="col-md-8 my-md-auto">
                        <div class="header_content">
                            <h4 class="header_heading"><span style="color:#369;">Get</span>  <span style="color:black">Glowing Refreshed</span> <span>Skin with our</span></h4>
                            <!-- <p>Laser Hair Removal</p> -->
                            <p><span style="color:#369;">Luxurious Facial Treatments.</p>
                            <div class="fifty_off">
                                <div class="get_ver">
                                    <!-- <span>GET</span> -->
                                    <span>UP</span>
                                    <span> TO</span>
                                </div>
                                <span class="persent">50 <sup>%</sup></span>
                                <span class="off">OFF</span>
                            </div>
                            <h4 class="laser">ON Skin Treatments</h4>
                        </div>
                    </div>
                    <div class="col-md-2 h-100">
                        <button class="btn hero_btn" data-bs-toggle="modal" data-bs-target="#exampleModal">Book
                            Now</button>
                    </div>
                </div>
            </div>
        </section>
        <!-- hero section end -->

        <!-- after hero section start -->
        <section id="service">
            <div class="container py-4">
                <div class="col-md-5 m-auto">
                    <h1 class="heading">WHAT DO YOU NEED ?</h1>
                </div>
                <div class="col-md-12 mt-lg-5">
                    <div class="col-md-12 m-auto">
                        <div class="row text-center px-3">
                            <div class="col-md-3 cards mb-4 mb-lg-4">
                                <div class="service_card">
                                    <div class="card_img">
                                        <img src="assets/img/HYDAR-FACIAL.png" alt="" class="img-fluid">
                                    </div>
                                    <div class="card_content">
                                        <span class="card_heading">Hydra Facial</span>
                                        <span class="price">Rs 4,999</span>
                                        <span class="mrp"><del>Rs 9,999</del></span>
                                        <button class="btn book_now" data-name="Full Body hair removal"
                                            data-bs-toggle="modal" data-bs-target="#exampleModal1">Book Now</button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 cards mb-4 mb-lg-4">
                                <div class="service_card">
                                    <div class="card_img">
                                        <img src="assets/img/Carbon-Facial.png" alt="" class="img-fluid">
                                    </div>
                                    <div class="card_content">
                                        <span class="card_heading">Carbon Facial</span>
                                        <span class="price">Rs 1,499</span>
                                        <span class="mrp"><del>Rs 2,999</del></span>
                                        <button class="btn book_now" data-name="Side lock hair removal"
                                            data-bs-toggle="modal" data-bs-target="#exampleModal2">Book Now</button>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-3 cards mb-4 mb-lg-4">
                                <div class="service_card">
                                    <div class="card_img">
                                        <img src="assets/img/Vampire-Facial.png" alt="" class="img-fluid">
                                    </div>
                                    <div class="card_content">
                                        <span class="card_heading">Vampire Facial</span>
                                        <span class="price">Rs 1,499</span>
                                        <span class="mrp"><del>Rs 2,999</del></span>
                                        <button class="btn book_now" data-name="Underarms hair removal"
                                            data-bs-toggle="modal" data-bs-target="#exampleModal3">Book Now</button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 cards mb-4 mb-lg-4">
                                <div class="service_card">
                                    <div class="card_img">
                                        <img src="assets/img/Skin-Lighting.png" alt="" class="img-fluid">
                                    </div>
                                    <div class="card_content">
                                        <span class="card_heading">Skin Lighting Facial</span>
                                        <span class="price">Rs 1,499</span>
                                        <span class="mrp"><del>Rs 2,999</del></span>
                                        <button class="btn book_now" data-name="Upper lip/Chin hair removal"
                                            data-bs-toggle="modal" data-bs-target="#exampleModal4">Book Now</button>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- after hero section end -->

        <!--benefites points section start -->
        <section class="benefit mbenefits">
            <div class="container-fluid h-100">
                <div class="row h-100">
                    <div class="col-md-5 mt-4 ms-auto mt-auto mb-5">
                        <div class="wcu">
                            <h3 class="wcu_heading">Benefits Of Hydrafacial</h3>
                            <div class="benefits">
                                <div class="points">
                                    <i class="fa-solid fa-check" style="color: #336799;"></i>
                                    <div>Remove Fine lines</div>
                                </div>
                                <div class="points">
                                    <i class="fa-solid fa-check" style="color: #336799;"></i>
                                    <div>Reduces Open Pores</div>
                                </div>
                                <div class="points">
                                    <i class="fa-solid fa-check" style="color: #336799;"></i>
                                    <div>Reduces Pigmentation</div>
                                </div>
                                <div class="points">
                                    <i class="fa-solid fa-check" style="color: #336799;"></i>
                                    <div>Improve Skin Texture</div>
                                </div>
                                <div class="points">
                                    <i class="fa-solid fa-check" style="color: #336799;"></i>
                                    <div>Makes Skin Firm</div>
                                </div>
                                <div class="points">
                                    <i class="fa-solid fa-check" style="color: #336799;"></i>
                                    <div>Hydrates Skin</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- benefites points us section end -->

        <!-- why choose us section start -->
        <section class="whychooseus mwhychooseus">
            <div class="container-fluid h-100">
                <div class="row h-100">
                    <div class="col-md-5 mt-4 ms-auto">
                        <div class="wcu">
                            <h3 class="wcu_heading">Why Choose Us</h3>
                            <p class="wcu_pra mb-3">Our clinic has a team of certified and experienced technicians who
                                are
                                dedicated to providing personalized attention and care to each client. We understand
                                that every client's needs are different, which is why we take the time to understand
                                your specific requirements and recommend the best treatment plan for you.</p>
                            <div class="pointss">
                                <div class="point">
                                    <img src="assets/img/1.png" alt="" class="img-fluid">
                                    <div><strong>100% NATURAL</strong><br>PRODUCTS</div>
                                </div>
                                <div class="point">
                                    <img src="assets/img/2.png" alt="" class="img-fluid">
                                    <div><strong>PROFESSIONAL</strong><br>STAFFS</div>
                                </div>
                                <div class="point">
                                    <img src="assets/img/3.png" alt="" class="img-fluid">
                                    <div><strong>SPECIAL OFFERS</strong><br>FOR YOU</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- why choose us section end -->

        <!-- about section start -->
        <section class="about py-5 px-3">
            <div class="container">
                <div class="row ">
                    <div class="col-md-5 ms-auto">
                        <div class="about-us">
                            <p>
                            <h3>About Gliss</h3>
                            If you're looking for full-body hair removal, our clinic offers a comprehensive service
                            that
                            covers all parts of the body, from the arms and legs to the chest and back. We are a
                            full-service laser hair removal, we use the latest technology and equipment to ensure
                            safe,
                            effective, and pain-free treatment for our clients. Laser hair removal has become an
                            increasingly popular method of hair removal, thanks to its effectiveness and
                            long-lasting
                            results. If you're looking for the best laser hair removal clinic in Noida, look no
                            further than
                            our clinic. We offer a range of laser hair removal services, including full body hair
                            removal,
                            underarms hair removal, Facial hair removal, and bikini hair removal.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- about section end -->


        <!-- Before After start -->
        <section class="before_after">
            <img src="assets/img/Before After.jpg" alt="" class="img-fluid d-none d-lg-block d-md-block d-sm-none">
            <img src="assets/img/Before After_Mobile.jpg" alt=""
                class="img-fluid d-block d-lg-none d-md-none d-sm-block">
        </section>
        <!-- Before After end -->

        <!-- faq section start -->
        <section class="faq py-5" id="faq">
            <div class="container">
                <div class="row">
                    <div class="col-md-10 m-auto mt-lg-2 mb-lg-5 text-center">
                        <h4 class="content_heading">FAQ'S About Laser hair reduction</h4>
                    </div>
                    <div class="col-md-10 m-auto">
                        <div class="accordion laser_faq" id="accordionExample">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button heading_accordion" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true"
                                        aria-controls="collapseOne">
                                        what is laser hair removal treatment?
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show"
                                    aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                    <div class="accordion-body accordion_para">
                                        <strong> Laser hair removal is a way to get rid of unwanted hair on your
                                            body.</strong>
                                        During the treatment, a special machine sends a strong beam of light onto your
                                        skin. This light goes into the hair follicle, which is where hair grows from.
                                        The light damages the follicle so that it can't grow hair anymore. Laser hair
                                        removal is done by a trained professional and can be done on many parts of the
                                        body, like the legs, arms, and underarms. It's often better than other ways of
                                        removing hair, like shaving or waxing, because it can give long-lasting results.
                                        However, it may take multiple sessions to work well and can cause temporary
                                        redness or swelling.

                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingTwo">
                                    <button class="accordion-button heading_accordion collapsed" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false"
                                        aria-controls="collapseTwo">
                                        Is Laser Hair Reduction permanent?
                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body accordion_para">
                                        <strong>Laser hair reduction can provide long-term hair reduction, but it is not
                                            considered a permanent hair removal solution.</strong> The treatment works
                                        by damaging the hair follicle to inhibit future hair growth, but some follicles
                                        may regrow hair over time. The amount of hair reduction can vary depending on
                                        the individual's hair and skin type, as well as other factors such as hormonal
                                        changes. However, many patients report that the results of laser hair reduction
                                        can last for several months to years. It is also important to note that
                                        maintenance sessions may be necessary to maintain the results of the treatment
                                        over time. Overall, laser hair reduction can provide long-lasting results and is
                                        an effective alternative to traditional hair removal methods.
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingThree">
                                    <button class="accordion-button heading_accordion collapsed" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false"
                                        aria-controls="collapseThree">
                                        Is laser hair removal safe?
                                    </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse"
                                    aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                    <div class="accordion-body accordion_para">
                                        <strong>Laser hair removal is considered a safe cosmetic procedure when
                                            performed by a licensed and trained professional.</strong> The procedure has
                                        been approved by the FDA and has been used for many years with minimal side
                                        effects. However, there are some risks associated with laser hair removal, such
                                        as skin irritation, redness, and temporary discomfort. Rarely, there may be more
                                        serious side effects such as burns, scarring, or changes in skin pigmentation.
                                        To minimize the risks, it's important to choose a reputable provider and follow
                                        all pre- and post-treatment instructions carefully. It's also a good idea to
                                        discuss any concerns or medical conditions with the provider before undergoing
                                        laser hair removal.
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingFour">
                                    <button class="accordion-button heading_accordion collapsed" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false"
                                        aria-controls="collapseFour">
                                        How does laser hair removal work?
                                    </button>
                                </h2>
                                <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body accordion_para">
                                        <strong>Laser hair removal works by using concentrated beams of light to target
                                            the hair follicles on the skin.</strong> During the treatment, a laser emits
                                        a beam of light that is absorbed by the pigment in the hair follicle. This light
                                        energy converts to heat and damages the hair follicle, inhibiting future hair
                                        growth. The surrounding skin tissue is not affected by the laser, which makes
                                        laser hair removal a safe and effective procedure. The results of laser hair
                                        removal can vary depending on the individual, the area of the body being
                                        treated, and the number of sessions required. Multiple sessions are usually
                                        needed to achieve optimal results.
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingFive">
                                    <button class="accordion-button heading_accordion collapsed" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false"
                                        aria-controls="collapseFive">
                                        What are the side effects of laser hair removal?
                                    </button>
                                </h2>
                                <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body accordion_para">
                                        <strong>Although laser hair removal is generally considered a safe procedure,
                                            some potential side effects may occur.</strong> These can include temporary
                                        redness, swelling, and skin irritation in the treated area. In rare cases, more
                                        serious side effects such as burns, blistering, or changes in skin color may
                                        occur. It is important to follow all pre- and post-treatment instructions
                                        carefully to minimize the risk of complications. Avoiding sun exposure, tanning
                                        beds, and using sunscreen is recommended after treatment. It is also important
                                        to choose a qualified and experienced provider to minimize the risk of side
                                        effects. If you experience any unusual symptoms after laser hair removal
                                        treatment, it is important to contact your provider right away.

                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingSix">
                                    <button class="accordion-button heading_accordion collapsed" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false"
                                        aria-controls="collapseSix">
                                        Can laser hair removal be done on all skin types?
                                    </button>
                                </h2>
                                <div id="collapseSix" class="accordion-collapse collapse" aria-labelledby="headingSix"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body accordion_para">
                                        <strong>Laser hair removal can be done on most skin types, but the
                                            effectiveness</strong> of the treatment may vary depending on the
                                        individual's skin and hair type. Laser hair removal works by targeting the
                                        pigment in the hair follicle, so individuals with darker hair and lighter skin
                                        tend to respond best to the treatment. However, advances in laser technology
                                        have made it possible to treat a wider range of skin types, including those with
                                        darker skin. It is important to choose a provider with experience in treating a
                                        variety of skin types and to discuss any concerns about your skin type with them
                                        prior to treatment.
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- testimonial section start -->
        <section class="testimonial py-5" id="review">
            <div class="container">

                <div class="client-review">
                    <h4 class="content_heading text-center ">What Patient's Say Us</h4>
                    <div class="client-slide">
                        <div class="owl-carousel owl-theme owl-loaded owl-drag" id="carousel1">
                            <div class="owl-stage-outer">
                                <div class="owl-stage"
                                    style="transform: translate3d(-1125px, 0px, 0px); transition: all 0.25s ease 0s; width: 4504px;">
                                    <div class="owl-item " style="width: 365.333px; margin-right: 10px;">
                                        <div class="item">
                                            <div class="client-image">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <h5 class="card-title">Meenu jain</h5>
                                                        <h6 class="card-subtitle mb-2 "><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i></h6>
                                                        <p class="card-text">Amazing results after full leg laser hair
                                                            removal! Quick and virtually painless. Highly recommend for
                                                            a permanent hair removal solution.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="owl-item " style="width: 365.333px; margin-right: 10px;">
                                        <div class="item">
                                            <div class="client-image">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <h5 class="card-title">Sheetal sharma</h5>
                                                        <h6 class="card-subtitle mb-2 "><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i></h6>
                                                        <p class="card-text">Only in about 3 treatments on my underarms,
                                                            the hair is totally gone. I highly recommend this treatment
                                                            to anyone looking for a more permanent solution to underarm
                                                            hair removal.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="owl-item " style="width: 365.333px; margin-right: 10px;">
                                        <div class="item">
                                            <div class="client-image">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <h5 class="card-title">Karishma Rajput</h5>
                                                        <h6 class="card-subtitle mb-2 "><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i></h6>
                                                        <p class="card-text">The treatment was quick and virtually
                                                            painless, and I noticed a significant reduction in hair
                                                            growth after just a few sessions.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="owl-item " style="width: 365.333px; margin-right: 10px;">
                                        <div class="item">
                                            <div class="client-image">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <h5 class="card-title">Somya sharma</h5>
                                                        <h6 class="card-subtitle mb-2 "><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i></h6>
                                                        <p class="card-text">Laser hair removal for my upper lip and
                                                            chin has been life-changing. The treatment was painless,
                                                            quick and easy.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="owl-item " style="width: 365.333px; margin-right: 10px;">
                                        <div class="item">
                                            <div class="client-image">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <h5 class="card-title">Reetu panwar</h5>
                                                        <h6 class="card-subtitle mb-2 "><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i></h6>
                                                        <p class="card-text">I'm so happy with the results of my full
                                                            body laser hair removal treatment, and the treatment itself
                                                            was painless.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="owl-item " style="width: 365.333px; margin-right: 10px;">
                                        <div class="item">
                                            <div class="client-image">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <h5 class="card-title">Namrata kanojia</h5>
                                                        <h6 class="card-subtitle mb-2 "><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i><i
                                                                class="fa-solid fa-star"></i></h6>
                                                        <p class="card-text">Quick, easy, and painless - I highly
                                                            recommend laser hair removal .The staff were friendly and
                                                            professional throughout the process. </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- testimonial section end -->


        <!-- footer section start -->
        <section class="footer py-5">
            <div class="container">
                <div class="row">
                    <div class="col-md-10 m-auto footer_text">
                        <h4 class="footer_heading">
                            Contact Us
                        </h4>
                        <p class="addr">J-13, 1st Floor, J Block, Pocket G, Sector 18, Noida, Uttar Pradesh 201301</p>
                        <p class="numbers"> 01204134403 / +91 96670 22241</p>
                    </div>
                    <div class="col-md-6 m-auto text-center">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14016.140039861!2d77.324276!3d28.5687114!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce513e54b6813%3A0xb6f1d0c4da258a32!2sGliss%20Unisex%20Salon%20%7C%20Beauty%20%26%20Haircare!5e0!3m2!1sen!2sin!4v1681882840077!5m2!1sen!2sin"
                            width="100%" height="350" style="border:0;" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                    <div class="col-md-6 m-auto">
                        <div>
                            <div class="modal-content modal_bg">
                                <h4 class="text-center m-3"> BOOK AN APPOINTMENT NOW</h4>
                                <div class="modal-body">
                                    <form class="company_form">
                                        <div class="mb-3">
                                            <label for="name" class="col-form-label">Name</label>
                                            <input type="name" class="form-control" id="name" name="name"
                                                placeholder="Enter your Name" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="phone" class="col-form-label">Phone</label>
                                            <input type="tel" class="form-control" id="phone" name="phone"
                                                placeholder="Enter your phone" required>
                                        </div>
                                        <label for="select" class="col-form-label">Select Treatment</label>
                                        <select class="form-select" aria-label="Default select example" name="treatment"
                                            id="treatment" required>
                                            <option selected>Options</option>
                                            <option value="Hydra Facial" data-id='Hydra Facial'>Hydra Facial</option>
                                            <option value="Carbon Facial" data-id='Carbon Facial'>Carbon Facial</option>
                                            <option value="Vampire Facial" data-id='Vampire Facial'>Vampire Facial
                                            </option>
                                            <option value="Skin Lighting Facial" data-id='Skin Lighting Facial'>Skin
                                                Lighting Facial
                                            </option>
                                        </select>
                                        <br>
                                        <button type="submit" class="btn btn-dark appoint">Send message</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </section>
        <!-- footer section end -->


        <a href="tel:+919667022241" class="float-button-call"><i class="fa-solid fa-phone"></i></a>
        <a href="https://wa.me/919667022241" class="float-button-whatsapp"><i class="fa-brands fa-whatsapp"></i></a>
        
          <!-- footer -->
      <div style="height: 50px;"></div>
      <?php include 'includes/footer.php'?>
      <!-- footer -->
      <!-- footer CDN links -->
      <?php include 'includes/footer_script.php'?>
      <script src="libraries/sweetalert/sweetalert.min.js"></script>
      <script type="text/javascript" id="salonistScript" src="https://gliss.salonist.io/js/booking-button.js"></script>
      <!-- footer CDN links -->



        <!--pop up for cards -->

        <div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content modal_bg">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Get In Touch With Us</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="company_form">
                            <div class="mb-3">
                                <label for="name" class="col-form-label">Name</label>
                                <input type="name" class="form-control" id="name" name="name"
                                    placeholder="Enter your Name" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="col-form-label">Phone</label>
                                <input type="tel" class="form-control" id="phone" name="phone"
                                    placeholder="Enter your phone" required>
                            </div>
                            <label for="select" class="col-form-label">Select Treatment</label>
                            <select class="form-select" aria-label="Default select example" name="treatment"
                                id="treatment" required>
                                <option>Options</option>
                                <option value="Hydra Facial" data-id='Hydra Facial' selected>Hydra Facial</option>
                                <option value="Carbon Facial" data-id='Carbon Facial'>Carbon Facial</option>
                                <option value="Vampire Facial" data-id='Vampire Facial'>Vampire Facial
                                </option>
                                <option value="Skin Lighting Facial" data-id='Skin Lighting Facial'>Skin
                                    Lighting Facial
                                </option>
                            </select>
                            <br>
                            <button type="submit" class="btn btn-dark appoint">Send message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content modal_bg">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Get In Touch With Us</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="company_form">
                            <div class="mb-3">
                                <label for="name" class="col-form-label">Name</label>
                                <input type="name" class="form-control" id="name" name="name"
                                    placeholder="Enter your Name" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="col-form-label">Phone</label>
                                <input type="tel" class="form-control" id="phone" name="phone"
                                    placeholder="Enter your phone" required>
                            </div>
                            <label for="select" class="col-form-label">Select Treatment</label>
                            <select class="form-select" aria-label="Default select example" name="treatment"
                                id="treatment" required>
                                <option>Options</option>
                                <option value="Hydra Facial" data-id='Hydra Facial'>Hydra Facial</option>
                                <option value="Carbon Facial" data-id='Carbon Facial' selected>Carbon Facial</option>
                                <option value="Vampire Facial" data-id='Vampire Facial'>Vampire Facial
                                </option>
                                <option value="Skin Lighting Facial" data-id='Skin Lighting Facial'>Skin
                                    Lighting Facial
                                </option>
                            </select>
                            <br>
                            <button type="submit" class="btn btn-dark appoint">Send message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade" id="exampleModal3" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content modal_bg">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Get In Touch With Us</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="company_form">
                            <div class="mb-3">
                                <label for="name" class="col-form-label">Name</label>
                                <input type="name" class="form-control" id="name" name="name"
                                    placeholder="Enter your Name" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="col-form-label">Phone</label>
                                <input type="tel" class="form-control" id="phone" name="phone"
                                    placeholder="Enter your phone" required>
                            </div>
                            <label for="select" class="col-form-label">Select Treatment</label>
                            <select class="form-select" aria-label="Default select example" name="treatment"
                                id="treatment" required>
                                <option>Options</option>
                                <option value="Hydra Facial" data-id='Hydra Facial'>Hydra Facial</option>
                                <option value="Carbon Facial" data-id='Carbon Facial'>Carbon Facial</option>
                                <option value="Vampire Facial" data-id='Vampire Facial' selected>Vampire Facial
                                </option>
                                <option value="Skin Lighting Facial" data-id='Skin Lighting Facial'>Skin
                                    Lighting Facial
                                </option>
                            </select>
                            <br>
                            <button type="submit" class="btn btn-dark appoint">Send message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade" id="exampleModal4" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content modal_bg">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Get In Touch With Us</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="company_form">
                            <div class="mb-3">
                                <label for="name" class="col-form-label">Name</label>
                                <input type="name" class="form-control" id="name" name="name"
                                    placeholder="Enter your Name" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="col-form-label">Phone</label>
                                <input type="tel" class="form-control" id="phone" name="phone"
                                    placeholder="Enter your phone" required>
                            </div>
                            <label for="select" class="col-form-label">Select Treatment</label>
                            <select class="form-select" aria-label="Default select example" name="treatment"
                                id="treatment" required>
                                <option>Options</option>
                                <option value="Hydra Facial" data-id='Hydra Facial'>Hydra Facial</option>
                                <option value="Carbon Facial" data-id='Carbon Facial'>Carbon Facial</option>
                                <option value="Vampire Facial" data-id='Vampire Facial'>Vampire Facial
                                </option>
                                <option value="Skin Lighting Facial" data-id='Skin Lighting Facial' selected>Skin
                                    Lighting Facial
                                </option>
                            </select>
                            <br>
                            <button type="submit" class="btn btn-dark appoint">Send message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>




        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
            crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/jquery-3.6.3.min.js"></script> <!-- jquery cdn -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
        <script type="text/javascript">
            $('.company_form').submit(function (e) {
                e.preventDefault();
                // alert("Form submission prevented!");
                var formData = new FormData(this);
                $.ajax({
                    url: 'mailprocess.php',
                    type: 'POST',
                    contentType: false,
                    processData: false,
                    data: formData,
                    beforeSend: function () {
                        $('.appoint').attr('disabled', true);
                        $('.appoint').html('Please wait...');
                    },
                    success: function (data) {
                        console.log(data);
                        if (data == 1) {
                            $('.company_form').trigger('reset');
                            $("#exampleModal .close").click()
                            window.location = "thankyou.php";
                        }
                    }
                }).done(function () {
                    $('.appoint').attr('disabled', false);
                })

            })


            $(document).on('click', '.book_now', function () {
                var name = $(this).data('name');
                $('#exampleModalLabel').html(name);
            })
        </script>

        <script>
            $('#carousel1').owlCarousel({
                loop: true,
                margin: 10,
                nav: true,
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 2
                    },
                    1000: {
                        items: 2
                    }
                }
            })
            $('#carousel2').owlCarousel({
                loop: true,
                margin: 10,
                nav: true,
                autoplay: true,
                autoplayTimeout: 3000,
                autoplayHoverPause: true,
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 2
                    },
                    1000: {
                        items: 3
                    }
                }
            })
            $('#carousel3').owlCarousel({
                loop: true,
                margin: 10,
                nav: true,
                autoplay: true,
                autoplayTimeout: 3000,
                autoplayHoverPause: true,
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 1
                    },
                    1000: {
                        items: 1
                    }
                }
            })
        </script>

<script>$("#search-icon").click(function() {
    $(".nav").toggleClass("search");
    $(".nav").toggleClass("no-search");
    $(".search-input").toggleClass("search-active");
  });
  
  $('.menu-toggle').click(function(){
     $(".nav").toggleClass("mobile-nav");
     $(this).toggleClass("is-active");
  });</script>

        <!--<script src="assets/js/main.js"></script>-->


    </body>

</html>