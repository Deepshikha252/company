<?php 
//$conn = mysqli_connect('localhost','root','', 'salon');
$conn = mysqli_connect('localhost','sensejgz_salon1234','X7slj{rZl6Lf', 'sensejgz_salon_db');
$error = mysqli_connect_error($conn);
  print("Error: ".$error);
// db       - senserge_salon new - sensejgz_salon_db
// username - salon123  new - sensejgz_salon1234
// password - Or6)@k8Kn[#y  new  -  X7slj{rZl6Lf
 ?>