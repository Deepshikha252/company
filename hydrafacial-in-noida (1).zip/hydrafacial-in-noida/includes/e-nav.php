<!-- <span class="ecomm_nav ">
<a href="shop.php" class="position-relative">
<i class="bi bi-grid-3x3-gap"></i>
<span class="position-absolute top-0 font-2 font-w-100 start-100 translate-middle badge rounded-pill bg-danger">
2
<span class="visually-hidden">unread messages</span>
</span>
</a>
</span>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;
<span class="ecomm_nav "><a href="cart.php"><i class="bi bi-cart-fill"></i></a></span>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;
<span class="ecomm_nav ecomm_nav_active"><a href="wishlist.php"><i class="bi bi-heart-fill"></i></a></span>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;
<span class="ecomm_nav"><a href="user.php"><i class="bi bi-person-circle"></i></a></span> -->
<div class="right_side_nav">
        <span class="ecomm_nav ecomm_nav_border ">
        <a href="shop.php" class="position-relative">
        <i class="bi bi-grid-3x3-gap"></i>
        <span class="position-absolute top-0 font-2 font-w-100 start-100 translate-middle badge rounded-pill bg-danger">
        2
        <span class="visually-hidden">unread messages</span>
        </span>
        </a>
        </span>
        <br>
        <span class="ecomm_nav ecomm_nav_border "><a href="cart.php"><i class="bi bi-cart-fill"></i></a></span>
        <br>
        <span class="ecomm_nav ecomm_nav_border"><a href="wishlist.php"><i class="bi bi-heart-fill"></i></a></span><br>
        <span class="ecomm_nav ecomm_nav_border"><a href="user.php"><i class="bi bi-person-circle"></i></a></span><br>
      </div>